"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import { RoyalLogo } from "@/components/royal-logo"
import { ChatMessage } from "@/components/chat/chat-message"
import { ChatInput } from "@/components/chat/chat-input"
import { LLMTabs } from "@/components/chat/llm-tabs"
import { CodingMode } from "@/components/chat/coding-mode"
import { ChatHistory } from "@/components/chat/chat-history"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/contexts/auth-context"
import { multiLLMService } from "@/lib/llm-services"
import { chatHistoryService, type ChatSession, type Message, type LLMResponse } from "@/lib/chat-history"
import { Menu, X, Plus, History, Settings, User, LogOut, Code, MessageSquare } from "lucide-react"
import { useRouter } from "next/navigation"

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [llmResponses, setLLMResponses] = useState<LLMResponse[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [abortController, setAbortController] = useState<AbortController | null>(null)
  const [singleLLMMode, setSingleLLMMode] = useState<string | null>(null)
  const [codingMode, setCodingMode] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null)
  const [showHistory, setShowHistory] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { user, userProfile, logout } = useAuth()
  const router = useRouter()

  const menuItems = [
    { icon: Plus, label: "New Chat", action: () => handleNewChat() },
    { icon: History, label: "Chat History", action: () => setShowHistory(!showHistory) },
    { icon: Settings, label: "Settings", action: () => router.push("/settings") },
    { icon: User, label: "Profile", action: () => router.push("/profile") },
  ]

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, llmResponses, isGenerating])

  useEffect(() => {
    if (isGenerating || llmResponses.some((r) => r.isTyping)) {
      const interval = setInterval(scrollToBottom, 500)
      return () => clearInterval(interval)
    }
  }, [isGenerating, llmResponses])

  useEffect(() => {
    if (messages.length > 0 && user) {
      const saveChat = async () => {
        const title = messages[0]?.content.slice(0, 50) + (messages[0]?.content.length > 50 ? "..." : "")

        if (currentSessionId) {
          await chatHistoryService.updateChatSession(currentSessionId, messages, llmResponses)
        } else {
          const sessionId = await chatHistoryService.saveChatSession(user.uid, title, messages, llmResponses)
          if (sessionId) {
            setCurrentSessionId(sessionId)
          }
        }
      }

      const timeoutId = setTimeout(saveChat, 1000) // Debounce saves
      return () => clearTimeout(timeoutId)
    }
  }, [messages, llmResponses, user, currentSessionId])

  const handleNewChat = () => {
    setMessages([])
    setLLMResponses([])
    setCodingMode(false)
    setSidebarOpen(false)
    setCurrentSessionId(null)
    setShowHistory(false)
  }

  const handleSelectChat = (session: ChatSession) => {
    setMessages(session.messages)
    setLLMResponses(session.llmResponses)
    setCurrentSessionId(session.id)
    setShowHistory(false)
    setSidebarOpen(false)
  }

  const handleSendMessage = async (content: string, attachments?: File[]) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setIsLoading(true)
    setIsGenerating(true)

    const controller = new AbortController()
    setAbortController(controller)

    try {
      const enhancedPrompt = codingMode
        ? `You are a coding assistant. Please provide code examples and explanations for: ${content}`
        : content

      if (singleLLMMode) {
        await multiLLMService.generateSingleResponse(
          enhancedPrompt,
          singleLLMMode,
          (response) => {
            setLLMResponses([response])
          },
          () => {
            setIsLoading(false)
            setIsGenerating(false)
            setAbortController(null)
          },
          controller.signal,
        )
      } else {
        await multiLLMService.generateMultipleResponses(
          enhancedPrompt,
          (responses) => {
            setLLMResponses(responses)
          },
          () => {
            setIsLoading(false)
            setIsGenerating(false)
            setAbortController(null)
          },
          controller.signal,
        )
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Error generating responses:", error)
        setLLMResponses([
          {
            model: "System",
            content: "Sorry, there was an error generating responses. Please check your API keys and try again.",
            timestamp: new Date(),
            isTyping: false,
          },
        ])
      }
      setIsLoading(false)
      setIsGenerating(false)
      setAbortController(null)
    }
  }

  const handleSelectBest = (model: string) => {
    setLLMResponses((prev) =>
      prev.map((response) => ({
        ...response,
        isBest: response.model === model,
      })),
    )
  }

  const handleSignOut = async () => {
    await logout()
    setSidebarOpen(false)
  }

  const handleStopGeneration = () => {
    if (abortController) {
      abortController.abort()
      setAbortController(null)
    }
    setIsLoading(false)
    setIsGenerating(false)
  }

  const handleEditMessage = (messageId: string, newContent: string) => {
    setMessages((prev) => prev.map((msg) => (msg.id === messageId ? { ...msg, content: newContent } : msg)))
  }

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content)
  }

  const handleRegenerateResponse = async (messageContent: string) => {
    setLLMResponses([])
    setIsLoading(true)
    setIsGenerating(true)

    const controller = new AbortController()
    setAbortController(controller)

    try {
      const enhancedPrompt = codingMode
        ? `You are a coding assistant. Please provide code examples and explanations for: ${messageContent}`
        : messageContent

      if (singleLLMMode) {
        await multiLLMService.generateSingleResponse(
          enhancedPrompt,
          singleLLMMode,
          (response) => {
            setLLMResponses([response])
          },
          () => {
            setIsLoading(false)
            setIsGenerating(false)
            setAbortController(null)
          },
          controller.signal,
        )
      } else {
        await multiLLMService.generateMultipleResponses(
          enhancedPrompt,
          (responses) => {
            setLLMResponses(responses)
          },
          () => {
            setIsLoading(false)
            setIsGenerating(false)
            setAbortController(null)
          },
          controller.signal,
        )
      }
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Error generating responses:", error)
        setLLMResponses([
          {
            model: "System",
            content: "Sorry, there was an error generating responses. Please check your API keys and try again.",
            timestamp: new Date(),
            isTyping: false,
          },
        ])
      }
      setIsLoading(false)
      setIsGenerating(false)
      setAbortController(null)
    }
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-[#0A1D37] via-[#1A2F4A] to-[#0A1D37]">
        {sidebarOpen && (
          <motion.div
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <motion.aside
          className={`fixed left-0 top-0 h-full w-80 bg-[#0A1D37]/95 backdrop-blur-lg border-r border-yellow-400/20 z-50 transform transition-transform duration-300 ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          } lg:translate-x-0`}
        >
          <div className="p-6 h-full flex flex-col">
            <div className="flex items-center justify-between mb-8">
              <RoyalLogo size={32} />
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden text-yellow-400 hover:text-yellow-300"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>

            {userProfile && (
              <div className="mb-6 p-4 bg-yellow-400/5 rounded-lg border border-yellow-400/20">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full flex items-center justify-center">
                    <User className="h-5 w-5 text-[#0A1D37]" />
                  </div>
                  <div>
                    <p className="text-yellow-400 font-medium text-sm">{userProfile.displayName}</p>
                    <p className="text-yellow-400/70 text-xs">{userProfile.subscriptionPlan} plan</p>
                  </div>
                </div>
                <div className="flex justify-between text-xs text-yellow-400/70">
                  <span>XP: {userProfile.xpPoints}</span>
                  <span>Credits: {userProfile.credits}</span>
                </div>
              </div>
            )}

            <nav className="space-y-2 mb-6">
              {menuItems.map((item, index) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Button
                    variant="ghost"
                    onClick={item.action}
                    className={`w-full justify-start gap-3 transition-all duration-200 ${
                      item.label === "Chat History" && showHistory
                        ? "text-yellow-300 bg-yellow-400/10"
                        : "text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10"
                    }`}
                  >
                    <item.icon className="h-5 w-5" />
                    {item.label}
                  </Button>
                </motion.div>
              ))}

              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
                <Button
                  onClick={handleSignOut}
                  variant="ghost"
                  className="w-full justify-start gap-3 text-red-400 hover:text-red-300 hover:bg-red-400/10 transition-all duration-200"
                >
                  <LogOut className="h-5 w-5" />
                  Sign Out
                </Button>
              </motion.div>
            </nav>

            {showHistory && (
              <div className="flex-1 overflow-hidden">
                <ChatHistory onSelectChat={handleSelectChat} currentSessionId={currentSessionId} />
              </div>
            )}
          </div>
        </motion.aside>

        <main className="lg:ml-80 flex flex-col h-screen">
          <header className="sticky top-0 z-30 bg-[#0A1D37]/80 backdrop-blur-lg border-b border-yellow-400/20">
            <div className="flex items-center justify-between p-4">
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden text-yellow-400 hover:text-yellow-300"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>

              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-yellow-400" />
                <h1 className="text-lg font-semibold text-yellow-400">
                  {singleLLMMode ? `${singleLLMMode} Chat` : codingMode ? "Coding Assistant" : "Multi-LLM Chat"}
                </h1>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={singleLLMMode || "all"}
                  onChange={(e) => setSingleLLMMode(e.target.value === "all" ? null : e.target.value)}
                  className="bg-[#0A1D37] border border-yellow-400/30 text-yellow-400 rounded px-2 py-1 text-sm"
                >
                  <option value="all">All LLMs</option>
                  <option value="Gemini">Gemini Only</option>
                  <option value="GPT-4">GPT-4 Only</option>
                  <option value="DeepSeek">DeepSeek Only</option>
                  <option value="Qwen">Qwen Only</option>
                </select>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCodingMode(!codingMode)}
                  className={`${
                    codingMode
                      ? "text-yellow-400 bg-yellow-400/10 border border-yellow-400/30"
                      : "text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
                  }`}
                >
                  <Code className="h-4 w-4 mr-2" />
                  {codingMode ? "Exit Code Mode" : "Code Mode"}
                </Button>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-hidden flex flex-col">
            <div className="flex-1 overflow-y-auto p-4 space-y-6">
              {messages.length === 0 ? (
                <motion.div
                  className="flex flex-col items-center justify-center h-full text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <RoyalLogo size={64} />
                  <h2 className="text-2xl font-serif text-yellow-400 mt-4 mb-2">
                    {singleLLMMode
                      ? `Chat with ${singleLLMMode}`
                      : codingMode
                        ? "Ready to Code"
                        : "Start Your Royal Conversation"}
                  </h2>
                  <p className="text-yellow-400/70 max-w-md">
                    {singleLLMMode
                      ? `Get focused responses from ${singleLLMMode} AI model.`
                      : codingMode
                        ? "Describe your coding task and get help from multiple AI models with live code editing."
                        : "Ask anything and get responses from Gemini, GPT-4, DeepSeek, and Qwen simultaneously."}
                  </p>
                </motion.div>
              ) : (
                <>
                  {messages.map((message) => (
                    <ChatMessage
                      key={message.id}
                      message={message}
                      onEdit={handleEditMessage}
                      onCopy={handleCopyMessage}
                      onRegenerate={
                        message.role === "user" ? () => handleRegenerateResponse(message.content) : undefined
                      }
                    />
                  ))}

                  {llmResponses.length > 0 && (
                    <LLMTabs responses={llmResponses} onSelectBest={handleSelectBest} onCopy={handleCopyMessage} />
                  )}

                  {isGenerating && (
                    <div className="flex justify-center">
                      <Button
                        onClick={handleStopGeneration}
                        variant="outline"
                        className="border-red-400 text-red-400 hover:bg-red-400/10 bg-transparent"
                      >
                        Stop Generation
                      </Button>
                    </div>
                  )}

                  {codingMode && llmResponses.some((r) => !r.isTyping && r.content.includes("```")) && (
                    <CodingMode
                      code="const greeting = 'Hello from ROYAL GPT';\nconsole.log(greeting);"
                      language="javascript"
                      explanation="This is a simple JavaScript example that demonstrates variable declaration and console output."
                    />
                  )}
                </>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-yellow-400/20">
              <ChatInput
                onSendMessage={handleSendMessage}
                onToggleCodingMode={() => setCodingMode(!codingMode)}
                isLoading={isLoading}
                codingMode={codingMode}
                disabled={isGenerating}
              />
            </div>
          </div>
        </main>
      </div>
    </ProtectedRoute>
  )
}
