"use client"

import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { ProtectedRoute } from "@/components/auth/protected-route"
import { ArrowLeft, User } from "lucide-react"

export default function ProfilePage() {
  const router = useRouter()

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-[#0A1D37] via-[#1A2F4A] to-[#0A1D37]">
        <div className="container mx-auto px-4 py-8">
          <motion.div className="max-w-4xl mx-auto" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center gap-3 mb-8">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => router.back()}
                className="text-yellow-400 hover:text-yellow-300"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <User className="h-8 w-8 text-yellow-400" />
              <h1 className="text-3xl font-serif text-yellow-400">Profile</h1>
            </div>

            <div className="max-h-[calc(100vh-200px)] overflow-y-auto space-y-6 pr-2"></div>
          </motion.div>
        </div>
      </div>
    </ProtectedRoute>
  )
}
