"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Shield, Lock, Eye, Database } from "lucide-react"
import { useRouter } from "next/navigation"
import { RoyalLogo } from "@/components/royal-logo"

export default function PrivacyPolicyPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A1D37] via-[#1A2F4A] to-[#0A1D37]">
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            onClick={() => router.back()}
            className="text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back
          </Button>
          <RoyalLogo size={32} />
          <h1 className="text-3xl font-serif text-yellow-400">Privacy Policy</h1>
        </div>

        <motion.div className="space-y-6" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Shield className="h-6 w-6 text-yellow-400" />
              <h2 className="text-xl font-serif text-yellow-400">Your Privacy Matters</h2>
            </div>
            <p className="text-yellow-400/80 leading-relaxed">
              At ROYAL GPT, we are committed to protecting your privacy and ensuring the security of your personal
              information. This policy outlines how we collect, use, and protect your data.
            </p>
          </div>

          <div className="grid gap-6">
            <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
              <div className="flex items-center gap-3 mb-3">
                <Database className="h-5 w-5 text-yellow-400" />
                <h3 className="text-lg font-medium text-yellow-400">Data Collection</h3>
              </div>
              <div className="text-yellow-400/70 text-sm space-y-2">
                <p>• Account information (email, name, profile picture)</p>
                <p>• Chat conversations and message history</p>
                <p>• Usage analytics and preferences</p>
                <p>• Uploaded files and documents (processed securely)</p>
              </div>
            </div>

            <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
              <div className="flex items-center gap-3 mb-3">
                <Lock className="h-5 w-5 text-yellow-400" />
                <h3 className="text-lg font-medium text-yellow-400">Data Security</h3>
              </div>
              <div className="text-yellow-400/70 text-sm space-y-2">
                <p>• All data is encrypted in transit and at rest</p>
                <p>• Firebase Authentication for secure user management</p>
                <p>• Regular security audits and updates</p>
                <p>• No sharing of personal data with third parties</p>
              </div>
            </div>

            <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
              <div className="flex items-center gap-3 mb-3">
                <Eye className="h-5 w-5 text-yellow-400" />
                <h3 className="text-lg font-medium text-yellow-400">Your Rights</h3>
              </div>
              <div className="text-yellow-400/70 text-sm space-y-2">
                <p>• Access and download your data at any time</p>
                <p>• Delete your account and all associated data</p>
                <p>• Control your privacy settings and preferences</p>
                <p>• Opt out of analytics and data collection</p>
              </div>
            </div>
          </div>

          <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
            <h3 className="text-lg font-medium text-yellow-400 mb-3">Contact Us</h3>
            <p className="text-yellow-400/80 text-sm">
              If you have any questions about this Privacy Policy or your data, please contact us at{" "}
              <a href="mailto:buildanyproject@gmail.com" className="text-yellow-400 hover:underline">
                buildanyproject@gmail.com
              </a>
            </p>
            <p className="text-yellow-400/60 text-xs mt-4">Last updated: {new Date().toLocaleDateString()}</p>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
