"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Phone, Mail, MessageCircle, HelpCircle, Book, Users } from "lucide-react"
import { useRouter } from "next/navigation"
import { RoyalLogo } from "@/components/royal-logo"

export default function HelpContactPage() {
  const router = useRouter()

  const contactMethods = [
    {
      icon: Mail,
      title: "Email Support",
      description: "Get help via email",
      contact: "buildanyproject@gmail.com",
      action: () => window.open("mailto:buildanyproject@gmail.com"),
    },
    {
      icon: Phone,
      title: "Phone Support",
      description: "Call us directly",
      contact: "+91 8210180748",
      action: () => window.open("tel:+918210180748"),
    },
    {
      icon: MessageCircle,
      title: "Live Chat",
      description: "Chat with our AI assistant",
      contact: "Available 24/7",
      action: () => router.push("/chat"),
    },
  ]

  const helpTopics = [
    {
      icon: HelpCircle,
      title: "Getting Started",
      description: "Learn the basics of ROYAL GPT",
    },
    {
      icon: Book,
      title: "User Guide",
      description: "Comprehensive documentation",
      action: () => router.push("/user-guide"),
    },
    {
      icon: Users,
      title: "Community",
      description: "Join our user community",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A1D37] via-[#1A2F4A] to-[#0A1D37]">
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            onClick={() => router.back()}
            className="text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back
          </Button>
          <RoyalLogo size={32} />
          <h1 className="text-3xl font-serif text-yellow-400">Help & Contact</h1>
        </div>

        <motion.div className="space-y-8" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
            <h2 className="text-xl font-serif text-yellow-400 mb-4">Contact Support</h2>
            <div className="grid gap-4 md:grid-cols-3">
              {contactMethods.map((method, index) => (
                <motion.div
                  key={method.title}
                  className="bg-[#0A1D37]/30 rounded-lg border border-yellow-400/10 p-4 cursor-pointer hover:border-yellow-400/30 transition-colors"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={method.action}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <method.icon className="h-5 w-5 text-yellow-400" />
                    <h3 className="font-medium text-yellow-400">{method.title}</h3>
                  </div>
                  <p className="text-yellow-400/70 text-sm mb-2">{method.description}</p>
                  <p className="text-yellow-400 text-sm font-medium">{method.contact}</p>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
            <h2 className="text-xl font-serif text-yellow-400 mb-4">Help Topics</h2>
            <div className="grid gap-4 md:grid-cols-3">
              {helpTopics.map((topic, index) => (
                <motion.div
                  key={topic.title}
                  className="bg-[#0A1D37]/30 rounded-lg border border-yellow-400/10 p-4 cursor-pointer hover:border-yellow-400/30 transition-colors"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={topic.action}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <topic.icon className="h-5 w-5 text-yellow-400" />
                    <h3 className="font-medium text-yellow-400">{topic.title}</h3>
                  </div>
                  <p className="text-yellow-400/70 text-sm">{topic.description}</p>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
            <h3 className="text-lg font-medium text-yellow-400 mb-4">Frequently Asked Questions</h3>
            <div className="space-y-4">
              <div className="border-l-2 border-yellow-400/30 pl-4">
                <h4 className="text-yellow-400 font-medium mb-1">How do I use multiple AI models?</h4>
                <p className="text-yellow-400/70 text-sm">
                  Simply type your question and get responses from all models, or select a specific model from the
                  dropdown.
                </p>
              </div>
              <div className="border-l-2 border-yellow-400/30 pl-4">
                <h4 className="text-yellow-400 font-medium mb-1">Can I upload files for analysis?</h4>
                <p className="text-yellow-400/70 text-sm">
                  Yes, you can upload PDFs, documents, and images for AI analysis and processing.
                </p>
              </div>
              <div className="border-l-2 border-yellow-400/30 pl-4">
                <h4 className="text-yellow-400 font-medium mb-1">How is my data protected?</h4>
                <p className="text-yellow-400/70 text-sm">
                  All data is encrypted and stored securely. You can delete your account and data at any time.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
