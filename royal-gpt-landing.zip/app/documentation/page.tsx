import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Book, Code, MessageSquare, BarChart3, Zap, Shield, CheckCircle, ExternalLink } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function Documentation() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <ArrowLeft className="w-5 h-5 text-muted-foreground hover:text-foreground transition-colors" />
              <span className="text-muted-foreground hover:text-foreground transition-colors">Back to Home</span>
            </Link>
          </div>
          <div className="flex items-center space-x-2">
            <Image
              src="/images/royal-gpt-logo.png"
              alt="ROYAL GPT logo"
              width={32}
              height={32}
              className="rounded-lg"
            />
            <span className="text-xl font-bold text-foreground">ROYAL GPT</span>
          </div>
          <Button asChild>
            <a href="https://royal-gpt.base44.app/login?from_url=https://royal-gpt.base44.app">Get Started</a>
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="container mx-auto px-4 text-center">
          <Badge variant="secondary" className="mb-6">
            <Book className="w-4 h-4 mr-2" />
            Documentation
          </Badge>
          <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6 text-balance">
            ROYAL GPT
            <span className="text-primary block">Documentation</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto text-pretty">
            Complete guide to using ROYAL GPT's multi-LLM platform. Learn how to get the most out of each AI model for
            your specific needs.
          </p>
        </div>
      </section>

      {/* Quick Start */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Quick Start Guide</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Get started with ROYAL GPT in just a few simple steps
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-border">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <span className="text-2xl font-bold text-primary">1</span>
                </div>
                <CardTitle>Access the Platform</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base mb-4">
                  Visit our platform and start using all AI models immediately - no registration required.
                </CardDescription>
                <Button asChild className="w-full">
                  <a href="https://royal-gpt.base44.app/login?from_url=https://royal-gpt.base44.app">
                    Open Platform
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </a>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <span className="text-2xl font-bold text-accent">2</span>
                </div>
                <CardTitle>Choose Your Model</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base mb-4">
                  Select the AI model that best fits your task from our suite of 4 specialized models.
                </CardDescription>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Gemini Pro</Badge>
                  <Badge variant="secondary">ChatGPT 4</Badge>
                  <Badge variant="secondary">Deepseek R1</Badge>
                  <Badge variant="secondary">Qwen Coder</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <span className="text-2xl font-bold text-primary">3</span>
                </div>
                <CardTitle>Start Creating</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base mb-4">
                  Begin your conversation and get high-quality responses from the world's best AI models.
                </CardDescription>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <CheckCircle className="w-4 h-4 text-primary" />
                  Unlimited usage
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Model Guides */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Model Usage Guides</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Detailed guides for each AI model and their best use cases
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-border">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Image
                      src="/images/royal-gpt-logo.png"
                      alt="ROYAL GPT logo"
                      width={24}
                      height={24}
                      className="rounded-lg"
                    />
                  </div>
                  <div>
                    <CardTitle>Gemini Pro Guide</CardTitle>
                    <CardDescription>Research and academic excellence</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Perfect for research tasks, academic writing, and critical thinking. Excels at analyzing complex
                  topics and generating comprehensive notes.
                </p>
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Best For:</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Research paper writing and analysis</li>
                    <li>• Academic note-taking and summarization</li>
                    <li>• Complex problem-solving and reasoning</li>
                    <li>• Literature reviews and citations</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Sample Prompts:</h4>
                  <div className="bg-muted p-3 rounded-lg text-sm">
                    "Analyze the impact of climate change on global agriculture and provide a comprehensive research
                    summary with key findings."
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <MessageSquare className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <CardTitle>ChatGPT 4 Guide</CardTitle>
                    <CardDescription>Versatile general-purpose AI</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  The most versatile model for general conversations, content creation, and creative writing. Great for
                  everyday tasks and brainstorming.
                </p>
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Best For:</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Content creation and copywriting</li>
                    <li>• Creative writing and storytelling</li>
                    <li>• General conversations and Q&A</li>
                    <li>• Brainstorming and idea generation</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Sample Prompts:</h4>
                  <div className="bg-muted p-3 rounded-lg text-sm">
                    "Write a compelling blog post about the benefits of remote work, including practical tips for
                    productivity."
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>Deepseek R1 Guide</CardTitle>
                    <CardDescription>Advanced reasoning and analysis</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Specialized for complex reasoning, data analysis, and technical problem-solving. Excels at breaking
                  down complex problems step by step.
                </p>
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Best For:</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Data analysis and interpretation</li>
                    <li>• Complex mathematical problems</li>
                    <li>• Technical documentation</li>
                    <li>• Strategic planning and analysis</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Sample Prompts:</h4>
                  <div className="bg-muted p-3 rounded-lg text-sm">
                    "Analyze this sales data and provide insights on trends, patterns, and recommendations for improving
                    performance."
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <Code className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <CardTitle>Qwen Coder Guide</CardTitle>
                    <CardDescription>Programming and development expert</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Designed specifically for coding tasks. Generates clean code, debugs issues, and explains programming
                  concepts across multiple languages.
                </p>
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Best For:</h4>
                  <ul className="space-y-1 text-sm text-muted-foreground">
                    <li>• Code generation and optimization</li>
                    <li>• Debugging and error fixing</li>
                    <li>• Code reviews and explanations</li>
                    <li>• Algorithm implementation</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Sample Prompts:</h4>
                  <div className="bg-muted p-3 rounded-lg text-sm">
                    "Create a Python function that processes CSV data and generates a summary report with error
                    handling."
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Best Practices */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Best Practices</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Tips and techniques to get the best results from ROYAL GPT
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-border">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Be Specific</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  Provide clear, detailed prompts with context. The more specific you are, the better the AI can
                  understand and respond to your needs.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-accent" />
                </div>
                <CardTitle>Choose the Right Model</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  Match your task to the appropriate model. Use Qwen Coder for programming, Gemini Pro for research, and
                  ChatGPT 4 for general tasks.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <MessageSquare className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Iterate and Refine</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  Don't hesitate to ask follow-up questions or request clarifications. The AI can build on previous
                  responses for better results.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Image
                src="/images/royal-gpt-logo.png"
                alt="ROYAL GPT logo"
                width={32}
                height={32}
                className="rounded-lg"
              />
              <span className="text-xl font-bold text-foreground">ROYAL GPT</span>
            </div>
            <p className="text-muted-foreground mb-4">Need more help? Contact us at buildanyproject@gmail.com</p>
            <div className="flex justify-center space-x-4">
              <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                Home
              </Link>
              <Link href="/blog" className="text-muted-foreground hover:text-foreground transition-colors">
                Blog
              </Link>
              <a
                href="https://royal-gpt.base44.app/login?from_url=https://royal-gpt.base44.app"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Platform
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
