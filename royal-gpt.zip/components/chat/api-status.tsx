"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { validateAPIKeys } from "@/lib/api-config"
import { AlertTriangle, CheckCircle, RefreshCw } from "lucide-react"

export function APIStatus() {
  const [apiStatus, setApiStatus] = useState<{ isValid: boolean; missing: string[] }>({ isValid: true, missing: [] })
  const [isChecking, setIsChecking] = useState(false)

  const checkAPIStatus = () => {
    setIsChecking(true)
    setTimeout(() => {
      const status = validateAPIKeys()
      setApiStatus(status)
      setIsChecking(false)
    }, 1000)
  }

  useEffect(() => {
    checkAPIStatus()
  }, [])

  if (apiStatus.isValid) {
    return (
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-4">
        <Card className="bg-green-400/10 border-green-400/30 p-3">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-400" />
            <span className="text-green-400 text-sm font-medium">All LLM APIs Connected</span>
            <Badge variant="outline" className="border-green-400/30 text-green-400 ml-auto">
              4/4 Active
            </Badge>
          </div>
        </Card>
      </motion.div>
    )
  }

  return (
    <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-4">
      <Card className="bg-yellow-400/10 border-yellow-400/30 p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-yellow-400 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-yellow-400 font-medium mb-2">API Configuration Required</h4>
            <p className="text-yellow-400/80 text-sm mb-3">
              Some LLM services are not configured. Missing APIs: {apiStatus.missing.join(", ")}
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={checkAPIStatus}
                disabled={isChecking}
                className="border-yellow-400/30 text-yellow-400 hover:bg-yellow-400/10 bg-transparent"
              >
                {isChecking ? (
                  <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
                ) : (
                  <RefreshCw className="h-3 w-3 mr-1" />
                )}
                Recheck
              </Button>
              <Badge variant="outline" className="border-yellow-400/30 text-yellow-400">
                {4 - apiStatus.missing.length}/4 Active
              </Badge>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  )
}
