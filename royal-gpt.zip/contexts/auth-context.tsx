"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import {
  type User,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  GoogleAuthProvider,
  signInWithPopup,
} from "firebase/auth"
import { doc, setDoc, getDoc } from "firebase/firestore"
import { auth, db, isFirebaseConfigured } from "@/lib/firebase"

interface UserProfile {
  uid: string
  email: string
  displayName: string
  photoURL?: string
  xpPoints: number
  credits: number
  subscriptionPlan: "free" | "premium" | "royal"
  createdAt: Date
  lastLogin: Date
}

interface AuthContextType {
  user: User | null
  userProfile: UserProfile | null
  loading: boolean
  signUp: (email: string, password: string, displayName: string) => Promise<void>
  signIn: (email: string, password: string) => Promise<void>
  signInWithGoogle: () => Promise<void>
  logout: () => Promise<void>
  updateUserProfile: (data: Partial<UserProfile>) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isFirebaseConfigured()) {
      setLoading(false)
      return
    }

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user)
      if (user) {
        await loadUserProfile(user.uid)
      } else {
        setUserProfile(null)
      }
      setLoading(false)
    })

    return unsubscribe
  }, [])

  const loadUserProfile = async (uid: string) => {
    if (!isFirebaseConfigured()) return

    try {
      const docRef = doc(db, "users", uid)
      const docSnap = await getDoc(docRef)

      if (docSnap.exists()) {
        const data = docSnap.data()
        setUserProfile({
          ...data,
          createdAt: data.createdAt?.toDate(),
          lastLogin: data.lastLogin?.toDate(),
        } as UserProfile)
      }
    } catch (error) {
      console.error("Error loading user profile:", error)
    }
  }

  const createUserProfile = async (user: User, additionalData: any = {}) => {
    if (!isFirebaseConfigured()) return

    const userProfile: UserProfile = {
      uid: user.uid,
      email: user.email!,
      displayName: user.displayName || additionalData.displayName || "",
      photoURL: user.photoURL || "",
      xpPoints: 0,
      credits: 100, // Welcome credits
      subscriptionPlan: "free",
      createdAt: new Date(),
      lastLogin: new Date(),
      ...additionalData,
    }

    await setDoc(doc(db, "users", user.uid), userProfile)
    setUserProfile(userProfile)
  }

  const signUp = async (email: string, password: string, displayName: string) => {
    if (!isFirebaseConfigured()) {
      throw new Error("Firebase is not configured. Please add your Firebase environment variables.")
    }

    const { user } = await createUserWithEmailAndPassword(auth, email, password)
    await updateProfile(user, { displayName })
    await createUserProfile(user, { displayName })
  }

  const signIn = async (email: string, password: string) => {
    if (!isFirebaseConfigured()) {
      throw new Error("Firebase is not configured. Please add your Firebase environment variables.")
    }

    await signInWithEmailAndPassword(auth, email, password)
    if (auth.currentUser) {
      await setDoc(doc(db, "users", auth.currentUser.uid), { lastLogin: new Date() }, { merge: true })
    }
  }

  const signInWithGoogle = async () => {
    if (!isFirebaseConfigured()) {
      throw new Error("Firebase is not configured. Please add your Firebase environment variables.")
    }

    const provider = new GoogleAuthProvider()
    const { user } = await signInWithPopup(auth, provider)

    const docRef = doc(db, "users", user.uid)
    const docSnap = await getDoc(docRef)

    if (!docSnap.exists()) {
      await createUserProfile(user)
    } else {
      await setDoc(docRef, { lastLogin: new Date() }, { merge: true })
    }
  }

  const logout = async () => {
    if (!isFirebaseConfigured()) return
    await signOut(auth)
  }

  const updateUserProfile = async (data: Partial<UserProfile>) => {
    if (!user || !isFirebaseConfigured()) return

    await setDoc(doc(db, "users", user.uid), data, { merge: true })
    setUserProfile((prev) => (prev ? { ...prev, ...data } : null))
  }

  const value: AuthContextType = {
    user,
    userProfile,
    loading,
    signUp,
    signIn,
    signInWithGoogle,
    logout,
    updateUserProfile,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
