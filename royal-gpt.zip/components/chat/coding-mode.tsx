"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Copy, Download, Play, Eye, EyeOff } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Editor from "@monaco-editor/react"

interface CodingModeProps {
  code: string
  language: string
  explanation?: string
  onCodeChange?: (code: string) => void
  readOnly?: boolean
}

export function CodingMode({ code, language, explanation, onCodeChange, readOnly = false }: CodingModeProps) {
  const [showPreview, setShowPreview] = useState(false)
  const [previewContent, setPreviewContent] = useState("")
  const { toast } = useToast()

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(code)
      toast({
        title: "Code Copied!",
        description: "Code has been copied to clipboard",
      })
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Unable to copy code to clipboard",
        variant: "destructive",
      })
    }
  }

  const downloadCode = () => {
    const fileExtensions: Record<string, string> = {
      javascript: "js",
      typescript: "ts",
      python: "py",
      html: "html",
      css: "css",
      json: "json",
      markdown: "md",
    }

    const extension = fileExtensions[language] || "txt"
    const blob = new Blob([code], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `code.${extension}`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Code Downloaded!",
      description: `Code saved as code.${extension}`,
    })
  }

  const runCode = () => {
    if (language === "html" || language === "javascript") {
      setPreviewContent(code)
      setShowPreview(true)
    } else {
      toast({
        title: "Preview Not Available",
        description: "Live preview is only available for HTML and JavaScript",
        variant: "destructive",
      })
    }
  }

  return (
    <Card className="bg-[#0A1D37]/50 backdrop-blur-lg border-yellow-400/20 p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <h3 className="text-lg font-semibold text-yellow-400">Code Editor</h3>
          <Badge variant="outline" className="border-yellow-400/30 text-yellow-400">
            {language}
          </Badge>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={copyCode}
            className="text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
          >
            <Copy className="h-4 w-4 mr-1" />
            Copy
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={downloadCode}
            className="text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
          >
            <Download className="h-4 w-4 mr-1" />
            Download
          </Button>
          {(language === "html" || language === "javascript") && (
            <Button
              variant="ghost"
              size="sm"
              onClick={runCode}
              className="text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
            >
              <Play className="h-4 w-4 mr-1" />
              Preview
            </Button>
          )}
          {showPreview && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowPreview(!showPreview)}
              className="text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
            >
              {showPreview ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-4">
          <div className="border border-yellow-400/20 rounded-lg overflow-hidden">
            <Editor
              height="400px"
              language={language}
              value={code}
              onChange={(value) => onCodeChange?.(value || "")}
              theme="vs-dark"
              options={{
                readOnly,
                minimap: { enabled: false },
                fontSize: 14,
                lineNumbers: "on",
                roundedSelection: false,
                scrollBeyondLastLine: false,
                automaticLayout: true,
                tabSize: 2,
                wordWrap: "on",
              }}
            />
          </div>

          {explanation && (
            <Card className="bg-yellow-400/5 border-yellow-400/20 p-4">
              <h4 className="font-medium text-yellow-400 mb-2">Explanation</h4>
              <p className="text-yellow-400/80 text-sm leading-relaxed">{explanation}</p>
            </Card>
          )}
        </div>

        {showPreview && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-yellow-400">Live Preview</h4>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowPreview(false)}
                className="text-yellow-400/70 hover:text-yellow-400"
              >
                <EyeOff className="h-4 w-4" />
              </Button>
            </div>
            <div className="border border-yellow-400/20 rounded-lg overflow-hidden bg-white">
              <iframe srcDoc={previewContent} className="w-full h-96" title="Code Preview" sandbox="allow-scripts" />
            </div>
          </motion.div>
        )}
      </div>
    </Card>
  )
}
