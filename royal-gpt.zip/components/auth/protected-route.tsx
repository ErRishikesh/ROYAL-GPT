"use client"

import type React from "react"

import { useAuth } from "@/contexts/auth-context"
import { motion } from "framer-motion"
import { RoyalLogo } from "@/components/royal-logo"

interface ProtectedRouteProps {
  children: React.ReactNode
  fallback?: React.ReactNode
}

export function ProtectedRoute({ children, fallback }: ProtectedRouteProps) {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0A1D37] via-[#1A2F4A] to-[#0A1D37] flex items-center justify-center">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <RoyalLogo size={64} />
          <motion.div
            className="flex items-center justify-center mt-4 space-x-1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <div className="w-2 h-2 bg-yellow-400 rounded-full typing-dot"></div>
            <div className="w-2 h-2 bg-yellow-400 rounded-full typing-dot"></div>
            <div className="w-2 h-2 bg-yellow-400 rounded-full typing-dot"></div>
          </motion.div>
          <p className="text-yellow-400/70 mt-2">Loading your royal experience...</p>
        </motion.div>
      </div>
    )
  }

  if (!user) {
    return (
      fallback || (
        <div className="min-h-screen bg-gradient-to-br from-[#0A1D37] via-[#1A2F4A] to-[#0A1D37] flex items-center justify-center">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <RoyalLogo size={64} />
            <h2 className="text-2xl font-serif text-yellow-400 mt-4 mb-2">Authentication Required</h2>
            <p className="text-yellow-400/70">Please sign in to access this royal feature.</p>
          </motion.div>
        </div>
      )
    )
  }

  return <>{children}</>
}
