"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowLeft, MessageSquare, Settings, History, Code, Upload, Crown } from "lucide-react"
import { useRouter } from "next/navigation"
import { RoyalLogo } from "@/components/royal-logo"

export default function UserGuidePage() {
  const router = useRouter()

  const features = [
    {
      icon: MessageSquare,
      title: "Multi-LLM Chat",
      description: "Get responses from Gemini, GPT-4, DeepSeek, and Qwen simultaneously or choose a specific model.",
    },
    {
      icon: Code,
      title: "Coding Mode",
      description: "Enable coding mode for programming assistance with syntax highlighting and live preview.",
    },
    {
      icon: Upload,
      title: "File Upload",
      description: "Upload PDFs, documents, and images for AI analysis and processing.",
    },
    {
      icon: History,
      title: "Chat History",
      description: "Save, search, and continue previous conversations. Pin important chats for quick access.",
    },
    {
      icon: Settings,
      title: "Customization",
      description: "Personalize your experience with themes, preferences, and AI model settings.",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A1D37] via-[#1A2F4A] to-[#0A1D37]">
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            onClick={() => router.back()}
            className="text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back
          </Button>
          <RoyalLogo size={32} />
          <h1 className="text-3xl font-serif text-yellow-400">User Guide</h1>
        </div>

        <motion.div className="space-y-8" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
            <div className="flex items-center gap-3 mb-4">
              <Crown className="h-6 w-6 text-yellow-400" />
              <h2 className="text-xl font-serif text-yellow-400">Welcome to ROYAL GPT</h2>
            </div>
            <p className="text-yellow-400/80 leading-relaxed">
              ROYAL GPT is a premium multi-LLM chatbot platform that provides access to the world's most advanced AI
              models. Get simultaneous responses from multiple AI systems or focus on a specific model for specialized
              tasks.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="flex items-center gap-3 mb-3">
                  <feature.icon className="h-5 w-5 text-yellow-400" />
                  <h3 className="text-lg font-medium text-yellow-400">{feature.title}</h3>
                </div>
                <p className="text-yellow-400/70 text-sm leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>

          <div className="bg-[#0A1D37]/50 backdrop-blur-lg rounded-lg border border-yellow-400/20 p-6">
            <h3 className="text-lg font-medium text-yellow-400 mb-4">Getting Started</h3>
            <div className="space-y-3 text-yellow-400/80 text-sm">
              <div className="flex gap-3">
                <span className="text-yellow-400 font-medium">1.</span>
                <span>Start a new chat or continue from your chat history</span>
              </div>
              <div className="flex gap-3">
                <span className="text-yellow-400 font-medium">2.</span>
                <span>Choose between multi-LLM mode or select a specific AI model</span>
              </div>
              <div className="flex gap-3">
                <span className="text-yellow-400 font-medium">3.</span>
                <span>Enable coding mode for programming tasks or upload files for analysis</span>
              </div>
              <div className="flex gap-3">
                <span className="text-yellow-400 font-medium">4.</span>
                <span>Use the stop button to halt generation and edit/regenerate messages as needed</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
