import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Brain,
  Zap,
  Shield,
  Star,
  ArrowRight,
  CheckCircle,
  Code,
  BarChart3,
  MessageSquare,
  Mail,
  MapPin,
  Phone,
} from "lucide-react"

export default function RoyalGPTLanding() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/images/royal-gpt-logo.png" alt="ROYAL GPT logo" className="w-8 h-8 rounded-lg" />
            <span className="text-xl font-bold text-foreground">ROYAL GPT</span>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors">
              Features
            </a>
            <a href="#models" className="text-muted-foreground hover:text-foreground transition-colors">
              Models
            </a>
            <a href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors">
              Pricing
            </a>
            <a href="#comparison" className="text-muted-foreground hover:text-foreground transition-colors">
              Comparison
            </a>
            <a href="#faq" className="text-muted-foreground hover:text-foreground transition-colors">
              FAQ
            </a>
            <a href="/documentation" className="text-muted-foreground hover:text-foreground transition-colors">
              Documentation
            </a>
            <a href="/blog" className="text-muted-foreground hover:text-foreground transition-colors">
              Blog
            </a>
          </nav>
          <Button asChild>
            <a href="https://royal-gpt.base44.app/login?from_url=https://royal-gpt.base44.app">Get Started</a>
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 lg:py-32 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="container mx-auto px-4 text-center">
          <Badge variant="secondary" className="mb-6">
            <Star className="w-4 h-4 mr-2" />
            Multi-LLM Platform
          </Badge>
          <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6 text-balance">
            Multi-LLM Platform: Power of AI Models
            <span className="text-primary block">Combined</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto text-pretty">
            Stop juggling tabs and subscriptions - ROYAL GPT gives you access to all best-in-class AI models completely
            free. No more paying for multiple premium AI subscriptions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8" asChild>
              <a href="https://royal-gpt.base44.app/login?from_url=https://royal-gpt.base44.app">
                Get Started For Free
                <ArrowRight className="w-5 h-5 ml-2" />
              </a>
            </Button>
          </div>
          <div className="mt-12 flex items-center justify-center gap-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-primary" />
              No credit card required
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-primary" />
              Completely free access
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-primary" />
              All models included
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Why Choose ROYAL GPT</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              One platform with multiple specialized AI models for all your needs
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-border hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Brain className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Multiple AI Models</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  Access various large language models in one platform. Switch between models to find the perfect one
                  for your task.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-border hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-accent" />
                </div>
                <CardTitle>Cost Effective</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  Save 100% compared to using individual LLM services. Free access to all models with no subscription
                  fees.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-border hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <CardTitle>Secure & Private</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  Your data is protected with enterprise-grade security. We prioritize your privacy and confidentiality.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Models Section */}
      <section id="models" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Our AI Model Suite</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">Specialized models for different tasks</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-border">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Brain className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>Gemini Pro</CardTitle>
                    <CardDescription>Perfect for research and academic work</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Perfect for research, thinking tasks, and note-taking. Excellent for college notes and academic work.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Research & Analysis</Badge>
                  <Badge variant="secondary">Academic Writing</Badge>
                  <Badge variant="secondary">Note Taking</Badge>
                  <Badge variant="secondary">Critical Thinking</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <MessageSquare className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <CardTitle>ChatGPT 4</CardTitle>
                    <CardDescription>Most versatile for general tasks</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  The most versatile model for general conversations, content creation, and problem-solving.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">General Conversations</Badge>
                  <Badge variant="secondary">Content Creation</Badge>
                  <Badge variant="secondary">Problem Solving</Badge>
                  <Badge variant="secondary">Creative Writing</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>Deepseek R1</CardTitle>
                    <CardDescription>Specialized for research and analysis</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Specialized for research, data analysis, and complex reasoning tasks.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Data Analysis</Badge>
                  <Badge variant="secondary">Research Tasks</Badge>
                  <Badge variant="secondary">Complex Reasoning</Badge>
                  <Badge variant="secondary">Technical Writing</Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <Code className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <CardTitle>Qwen Coder</CardTitle>
                    <CardDescription>Designed for coding tasks</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Designed specifically for coding tasks. Generates, debugs, and explains code in multiple languages.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Code Generation</Badge>
                  <Badge variant="secondary">Debugging</Badge>
                  <Badge variant="secondary">Code Explanation</Badge>
                  <Badge variant="secondary">Multiple Languages</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Transparent Pricing</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">Choose the plan that works best for you</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="border-primary shadow-lg">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Free</CardTitle>
                <div className="text-4xl font-bold text-primary">
                  ₹0<span className="text-lg text-muted-foreground">/month</span>
                </div>
                <CardDescription>For everyone - completely free</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>Access to all 4 LLMs</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>Unlimited requests</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>Basic support</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>Standard response speed</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>Community access</span>
                </div>
                <Button className="w-full mt-6" size="lg" asChild>
                  <a href="https://royal-gpt.base44.app/login?from_url=https://royal-gpt.base44.app">Get Started</a>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">Enterprise</CardTitle>
                <div className="text-4xl font-bold text-foreground">Custom</div>
                <CardDescription>For businesses and organizations</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>All Free features</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>Dedicated instance</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>Custom model training</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>API access</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary" />
                  <span>Priority support & SLAs</span>
                </div>
                <Button variant="outline" className="w-full mt-6 bg-transparent" size="lg">
                  Contact Sales
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="comparison" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Price Comparison</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              See how ROYAL GPT saves you money compared to individual LLM services
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-border rounded-lg">
              <thead>
                <tr className="bg-muted">
                  <th className="border border-border p-4 text-left font-semibold">Feature</th>
                  <th className="border border-border p-4 text-center font-semibold">Gemini Pro</th>
                  <th className="border border-border p-4 text-center font-semibold">ChatGPT 4</th>
                  <th className="border border-border p-4 text-center font-semibold">Deepseek R1</th>
                  <th className="border border-border p-4 text-center font-semibold">Qwen Coder</th>
                  <th className="border border-border p-4 text-center font-semibold bg-primary/10">ROYAL GPT</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-border p-4 font-medium">Monthly Cost</td>
                  <td className="border border-border p-4 text-center">₹800</td>
                  <td className="border border-border p-4 text-center">₹1600</td>
                  <td className="border border-border p-4 text-center">₹1200</td>
                  <td className="border border-border p-4 text-center">₹1000</td>
                  <td className="border border-border p-4 text-center bg-primary/10 font-bold text-primary">₹0</td>
                </tr>
                <tr className="bg-muted/50">
                  <td className="border border-border p-4 font-medium">All Models Access</td>
                  <td className="border border-border p-4 text-center">❌</td>
                  <td className="border border-border p-4 text-center">❌</td>
                  <td className="border border-border p-4 text-center">❌</td>
                  <td className="border border-border p-4 text-center">❌</td>
                  <td className="border border-border p-4 text-center bg-primary/10 text-primary">✅</td>
                </tr>
                <tr>
                  <td className="border border-border p-4 font-medium">Requests Limit</td>
                  <td className="border border-border p-4 text-center">200/day</td>
                  <td className="border border-border p-4 text-center">100/day</td>
                  <td className="border border-border p-4 text-center">150/day</td>
                  <td className="border border-border p-4 text-center">180/day</td>
                  <td className="border border-border p-4 text-center bg-primary/10 font-bold text-primary">
                    Unlimited
                  </td>
                </tr>
                <tr className="bg-muted/50">
                  <td className="border border-border p-4 font-medium">Specialized Tasks</td>
                  <td className="border border-border p-4 text-center">✅</td>
                  <td className="border border-border p-4 text-center">✅</td>
                  <td className="border border-border p-4 text-center">✅</td>
                  <td className="border border-border p-4 text-center">✅</td>
                  <td className="border border-border p-4 text-center bg-primary/10 text-primary">✅</td>
                </tr>
                <tr>
                  <td className="border border-border p-4 font-medium">Coding Support</td>
                  <td className="border border-border p-4 text-center">Basic</td>
                  <td className="border border-border p-4 text-center">Basic</td>
                  <td className="border border-border p-4 text-center">Advanced</td>
                  <td className="border border-border p-4 text-center">Expert</td>
                  <td className="border border-border p-4 text-center bg-primary/10 font-bold text-primary">Expert</td>
                </tr>
                <tr className="bg-muted/50">
                  <td className="border border-border p-4 font-medium">Research Support</td>
                  <td className="border border-border p-4 text-center">Expert</td>
                  <td className="border border-border p-4 text-center">Advanced</td>
                  <td className="border border-border p-4 text-center">Expert</td>
                  <td className="border border-border p-4 text-center">Basic</td>
                  <td className="border border-border p-4 text-center bg-primary/10 font-bold text-primary">Expert</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section id="faq" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Find answers to common questions about ROYAL GPT
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="space-y-6">
              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-lg">How do I choose the right model for my task?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Use Gemini Pro for research and note-taking, ChatGPT 4 for general content, Deepseek R1 for data
                    analysis, and Qwen Coder for programming tasks. Our platform also provides recommendations based on
                    your input.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-lg">Is there really a free plan?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Yes! Our free plan gives you unlimited access to all models with no restrictions. This is perfect
                    for everyone.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-lg">How does ROYAL GPT save me money?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Instead of paying for multiple individual LLM subscriptions (which would cost ₹4600/month), you get
                    access to all models completely free.
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-lg">Can I use ROYAL GPT for commercial purposes?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Yes, our free plan allows commercial usage. For enterprise needs, please contact our sales team.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-lg">How do I get started?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Simply click "Get Started" and you'll have immediate access to all AI models. No payment required.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-border">
                <CardHeader>
                  <CardTitle className="text-lg">What if I need help choosing a model?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Our platform includes a model recommendation feature that suggests the best model based on your
                    task. You can also contact our support team for guidance.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Start Using Multiple LLMs Today</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of users who are getting better results with ROYAL GPT - completely free
          </p>
          <Button size="lg" className="text-lg px-8" asChild>
            <a href="https://royal-gpt.base44.app/login?from_url=https://royal-gpt.base44.app">
              Get Started For Free
              <ArrowRight className="w-5 h-5 ml-2" />
            </a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30">
        <div className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img src="/images/royal-gpt-logo.png" alt="ROYAL GPT logo" className="w-8 h-8 rounded-lg" />
                <span className="text-xl font-bold text-foreground">ROYAL GPT</span>
              </div>
              <p className="text-muted-foreground mb-4">
                The premier platform for accessing multiple large language models in one place.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                  </svg>
                </a>
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                  </svg>
                </a>
                <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-6.627-5.373-12-12-12z" />
                  </svg>
                </a>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Product</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <a href="#features" className="hover:text-foreground transition-colors">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#models" className="hover:text-foreground transition-colors">
                    Models
                  </a>
                </li>
                <li>
                  <a href="#pricing" className="hover:text-foreground transition-colors">
                    Pricing
                  </a>
                </li>
                <li>
                  <a href="#comparison" className="hover:text-foreground transition-colors">
                    Comparison
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Resources</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <a href="/documentation" className="hover:text-foreground transition-colors">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    API Reference
                  </a>
                </li>
                <li>
                  <a href="/blog" className="hover:text-foreground transition-colors">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-foreground transition-colors">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-4">Contact Us</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>buildanyproject@gmail.com</span>
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>Bihar, India</span>
                </li>
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>+91 8210810748</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2025 ROYAL GPT. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
