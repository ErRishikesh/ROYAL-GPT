"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { RoyalLogo } from "@/components/royal-logo"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { AuthModal } from "@/components/auth/auth-modal"
import { FirebaseStatus } from "@/components/firebase-status"
import { useAuth } from "@/contexts/auth-context"
import { MessageSquare, History, Settings, User, Menu, X, Plus, LogOut, BookOpen, Shield, Phone } from "lucide-react"
import { useRouter } from "next/navigation"

export default function RoyalGPTPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [authModalOpen, setAuthModalOpen] = useState(false)
  const { user, userProfile, logout } = useAuth()
  const router = useRouter()

  const menuItems = [
    { icon: Plus, label: "New Chat", action: () => router.push("/chat") },
    { icon: History, label: "Chat History", action: () => router.push("/chat") },
    { icon: Settings, label: "Settings", action: () => router.push("/settings") },
    { icon: User, label: "Profile", action: () => router.push("/profile") },
  ]

  const helpItems = [
    { icon: Phone, label: "Help & Contact", action: () => router.push("/help-contact") },
    { icon: BookOpen, label: "User Guide", action: () => router.push("/user-guide") },
    { icon: Shield, label: "Privacy Policy", action: () => router.push("/privacy-policy") },
  ]

  const handleSignOut = async () => {
    await logout()
    setSidebarOpen(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A1D37] via-[#1A2F4A] to-[#0A1D37]">
      {sidebarOpen && (
        <motion.div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <motion.aside
        className={`fixed left-0 top-0 h-full w-80 bg-[#0A1D37]/95 backdrop-blur-lg border-r border-yellow-400/20 z-50 transform transition-transform duration-300 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0`}
        initial={{ x: -320 }}
        animate={{ x: sidebarOpen ? 0 : -320 }}
        transition={{ type: "spring", damping: 25, stiffness: 200 }}
      >
        <div className="p-6 h-full flex flex-col">
          <div className="flex items-center justify-between mb-8">
            <RoyalLogo size={32} />
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden text-yellow-400 hover:text-yellow-300"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {user && userProfile && (
            <div className="mb-6 p-4 bg-yellow-400/5 rounded-lg border border-yellow-400/20">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-[#0A1D37]" />
                </div>
                <div>
                  <p className="text-yellow-400 font-medium text-sm">{userProfile.displayName}</p>
                  <p className="text-yellow-400/70 text-xs">{userProfile.subscriptionPlan} plan</p>
                </div>
              </div>
              <div className="flex justify-between text-xs text-yellow-400/70">
                <span>XP: {userProfile.xpPoints}</span>
                <span>Credits: {userProfile.credits}</span>
              </div>
            </div>
          )}

          <div className="flex-1 overflow-y-auto">
            {/* Main Navigation */}
            <div className="mb-6">
              <h3 className="text-yellow-400/60 text-xs font-semibold uppercase tracking-wider mb-3">Dashboard</h3>
              <nav className="space-y-2">
                {menuItems.map((item, index) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Button
                      variant="ghost"
                      onClick={item.action}
                      className="w-full justify-start gap-3 text-yellow-400 hover:text-yellow-300 hover:bg-yellow-400/10 transition-all duration-200"
                    >
                      <item.icon className="h-5 w-5" />
                      {item.label}
                    </Button>
                  </motion.div>
                ))}
              </nav>
            </div>

            {/* Help & Support Section */}
            <div className="mb-6">
              <h3 className="text-yellow-400/60 text-xs font-semibold uppercase tracking-wider mb-3">Help & Support</h3>
              <nav className="space-y-2">
                {helpItems.map((item, index) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: (menuItems.length + index) * 0.1 }}
                  >
                    <Button
                      variant="ghost"
                      onClick={item.action}
                      className="w-full justify-start gap-3 text-yellow-400/70 hover:text-yellow-300 hover:bg-yellow-400/5 transition-all duration-200"
                    >
                      <item.icon className="h-4 w-4" />
                      {item.label}
                    </Button>
                  </motion.div>
                ))}
              </nav>
            </div>
          </div>

          {/* Sign Out Button */}
          {user && (
            <div className="pt-4 border-t border-yellow-400/20">
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
                <Button
                  variant="ghost"
                  onClick={handleSignOut}
                  className="w-full justify-start gap-3 text-red-400 hover:text-red-300 hover:bg-red-400/10 transition-all duration-200"
                >
                  <LogOut className="h-5 w-5" />
                  Sign Out
                </Button>
              </motion.div>
            </div>
          )}
        </div>
      </motion.aside>

      <main className={`transition-all duration-300 ${sidebarOpen ? "lg:ml-80" : "lg:ml-80"}`}>
        <header className="sticky top-0 z-30 bg-[#0A1D37]/80 backdrop-blur-lg border-b border-yellow-400/20">
          <div className="flex items-center justify-between p-4">
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden text-yellow-400 hover:text-yellow-300"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>

            <div className="hidden lg:block">
              <RoyalLogo size={28} />
            </div>

            <div className="flex items-center gap-2">
              {user ? (
                <div className="flex items-center gap-2">
                  <span className="text-yellow-400 text-sm">Welcome, {userProfile?.displayName}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSignOut}
                    className="border-red-400/30 text-red-400 hover:bg-red-400/10 bg-transparent"
                  >
                    Sign Out
                  </Button>
                </div>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setAuthModalOpen(true)}
                  className="border-yellow-400/30 text-yellow-400 hover:bg-yellow-400/10 bg-transparent"
                >
                  Sign In
                </Button>
              )}
            </div>
          </div>
        </header>

        <div className="flex flex-col items-center justify-center min-h-[calc(100vh-80px)] p-6">
          <div className="w-full max-w-4xl mb-6">
            <FirebaseStatus />
          </div>

          <motion.div
            className="text-center max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <RoyalLogo size={80} />

            <motion.h1
              className="text-4xl md:text-6xl font-serif font-bold bg-gradient-to-r from-yellow-400 via-yellow-200 to-yellow-400 bg-clip-text text-transparent mt-6 mb-4"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              Welcome to ROYAL GPT
            </motion.h1>

            <motion.p
              className="text-xl text-yellow-400/80 mb-8 max-w-2xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
            >
              Experience the luxury of AI with our premium multi-LLM platform. Chat with Gemini, GPT, DeepSeek, and Qwen
              all in one place.
            </motion.p>

            <motion.div
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.8 }}
            >
              {[
                { name: "Gemini Pro", desc: "Google's advanced AI" },
                { name: "GPT-4", desc: "OpenAI's flagship model" },
                { name: "DeepSeek R1", desc: "Reasoning specialist" },
                { name: "Qwen Coder", desc: "Code generation expert" },
              ].map((model, index) => (
                <Card
                  key={model.name}
                  className="p-4 bg-yellow-400/5 border-yellow-400/20 hover:bg-yellow-400/10 transition-all duration-200"
                >
                  <h3 className="font-semibold text-yellow-400 mb-1">{model.name}</h3>
                  <p className="text-sm text-yellow-400/70">{model.desc}</p>
                </Card>
              ))}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.9, duration: 0.5 }}
            >
              {user ? (
                <Button
                  size="lg"
                  onClick={() => router.push("/chat")}
                  className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-[#0A1D37] hover:from-yellow-500 hover:to-yellow-600 font-semibold px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Start Chatting
                </Button>
              ) : (
                <Button
                  size="lg"
                  onClick={() => setAuthModalOpen(true)}
                  className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-[#0A1D37] hover:from-yellow-500 hover:to-yellow-600 font-semibold px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Sign In to Start
                </Button>
              )}
            </motion.div>
          </motion.div>
        </div>
      </main>

      <AuthModal isOpen={authModalOpen} onClose={() => setAuthModalOpen(false)} />
    </div>
  )
}
