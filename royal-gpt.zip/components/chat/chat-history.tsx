"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { chatHistoryService, type ChatSession } from "@/lib/chat-history"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MessageSquare, Pin, PinOff, Trash2, Edit3, Check, X, Clock, Search } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

interface ChatHistoryProps {
  onSelectChat: (session: ChatSession) => void
  currentSessionId?: string
}

export function ChatHistory({ onSelectChat, currentSessionId }: ChatHistoryProps) {
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editTitle, setEditTitle] = useState("")
  const { user } = useAuth()

  useEffect(() => {
    if (!user) return

    const unsubscribe = chatHistoryService.subscribeToUserChats(user.uid, (chats) => {
      setChatSessions(chats)
    })

    return unsubscribe
  }, [user])

  const filteredChats = chatSessions.filter(
    (chat) =>
      chat.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      chat.messages.some((msg) => msg.content.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const pinnedChats = filteredChats.filter((chat) => chat.isPinned)
  const regularChats = filteredChats.filter((chat) => !chat.isPinned)

  const handleDeleteChat = async (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (confirm("Are you sure you want to delete this chat?")) {
      await chatHistoryService.deleteChatSession(sessionId)
    }
  }

  const handleTogglePin = async (sessionId: string, isPinned: boolean, e: React.MouseEvent) => {
    e.stopPropagation()
    await chatHistoryService.togglePinChatSession(sessionId, !isPinned)
  }

  const handleStartEdit = (sessionId: string, currentTitle: string, e: React.MouseEvent) => {
    e.stopPropagation()
    setEditingId(sessionId)
    setEditTitle(currentTitle)
  }

  const handleSaveEdit = async (sessionId: string) => {
    if (editTitle.trim()) {
      await chatHistoryService.renameChatSession(sessionId, editTitle.trim())
    }
    setEditingId(null)
    setEditTitle("")
  }

  const handleCancelEdit = () => {
    setEditingId(null)
    setEditTitle("")
  }

  const ChatItem = ({ chat }: { chat: ChatSession }) => (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className={`group p-3 rounded-lg border transition-all duration-200 cursor-pointer ${
        currentSessionId === chat.id
          ? "bg-yellow-400/10 border-yellow-400/30 shadow-lg"
          : "bg-white/5 border-white/10 hover:bg-white/10 hover:border-yellow-400/20"
      }`}
      onClick={() => onSelectChat(chat)}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          {editingId === chat.id ? (
            <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
              <Input
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                className="h-7 text-sm bg-[#0A1D37] border-yellow-400/30 text-yellow-400"
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSaveEdit(chat.id)
                  if (e.key === "Escape") handleCancelEdit()
                }}
                autoFocus
              />
              <Button
                size="sm"
                variant="ghost"
                className="h-7 w-7 p-0 text-green-400 hover:text-green-300"
                onClick={() => handleSaveEdit(chat.id)}
              >
                <Check className="h-3 w-3" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="h-7 w-7 p-0 text-red-400 hover:text-red-300"
                onClick={handleCancelEdit}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 mb-1">
                <MessageSquare className="h-3 w-3 text-yellow-400/70 flex-shrink-0" />
                <h3 className="text-sm font-medium text-yellow-400 truncate">{chat.title}</h3>
                {chat.isPinned && <Pin className="h-3 w-3 text-yellow-400 flex-shrink-0" />}
              </div>
              <div className="flex items-center gap-2 text-xs text-yellow-400/50">
                <Clock className="h-3 w-3" />
                <span>{formatDistanceToNow(chat.updatedAt, { addSuffix: true })}</span>
                <span>•</span>
                <span>{chat.messages.length} messages</span>
              </div>
            </>
          )}
        </div>

        {editingId !== chat.id && (
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0 text-yellow-400/70 hover:text-yellow-400"
              onClick={(e) => handleTogglePin(chat.id, chat.isPinned || false, e)}
            >
              {chat.isPinned ? <PinOff className="h-3 w-3" /> : <Pin className="h-3 w-3" />}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0 text-yellow-400/70 hover:text-yellow-400"
              onClick={(e) => handleStartEdit(chat.id, chat.title, e)}
            >
              <Edit3 className="h-3 w-3" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0 text-red-400/70 hover:text-red-400"
              onClick={(e) => handleDeleteChat(chat.id, e)}
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        )}
      </div>
    </motion.div>
  )

  return (
    <div className="space-y-4 h-full flex flex-col">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-yellow-400/50" />
        <Input
          placeholder="Search chats..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 bg-white/5 border-white/10 text-yellow-400 placeholder:text-yellow-400/50 focus:border-yellow-400/30"
        />
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-thin scrollbar-thumb-yellow-400/20 scrollbar-track-transparent">
        <AnimatePresence>
          {pinnedChats.length > 0 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <h4 className="text-xs font-medium text-yellow-400/70 mb-2 flex items-center gap-2">
                <Pin className="h-3 w-3" />
                Pinned
              </h4>
              <div className="space-y-2">
                {pinnedChats.map((chat) => (
                  <ChatItem key={chat.id} chat={chat} />
                ))}
              </div>
            </motion.div>
          )}

          {regularChats.length > 0 && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {pinnedChats.length > 0 && <h4 className="text-xs font-medium text-yellow-400/70 mb-2">Recent</h4>}
              <div className="space-y-2">
                {regularChats.map((chat) => (
                  <ChatItem key={chat.id} chat={chat} />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {filteredChats.length === 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-8 text-yellow-400/50">
            <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">{searchQuery ? "No chats found" : "No chat history yet"}</p>
            <p className="text-xs mt-1">
              {searchQuery ? "Try a different search term" : "Start a conversation to see it here"}
            </p>
          </motion.div>
        )}
      </div>
    </div>
  )
}
