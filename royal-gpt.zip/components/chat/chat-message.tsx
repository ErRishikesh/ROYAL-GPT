"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Copy, Volume2, VolumeX, User, Crown, Edit, RotateCcw, Check, X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import ReactMarkdown from "react-markdown"
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter"
import { atomDark } from "react-syntax-highlighter/dist/esm/styles/prism"

interface ChatMessageProps {
  message: {
    id: string
    content: string
    role: "user" | "assistant"
    model?: string
    timestamp: Date
    isTyping?: boolean
  }
  isLast?: boolean
  onEdit?: (messageId: string, newContent: string) => void
  onCopy?: (content: string) => void
  onRegenerate?: () => void
}

export function ChatMessage({ message, isLast, onEdit, onCopy, onRegenerate }: ChatMessageProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [editContent, setEditContent] = useState(message.content)
  const { toast } = useToast()

  const formatTimestamp = (timestamp: any) => {
    try {
      let date: Date

      if (!timestamp) {
        return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      }

      // Handle Firestore Timestamp
      if (timestamp.toDate && typeof timestamp.toDate === "function") {
        date = timestamp.toDate()
      }
      // Handle Date object
      else if (timestamp instanceof Date) {
        date = timestamp
      }
      // Handle string or number
      else {
        date = new Date(timestamp)
      }

      // Validate the date
      if (isNaN(date.getTime())) {
        return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      }

      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } catch (error) {
      console.log("[v0] Timestamp formatting error:", error)
      return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }
  }

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      if (onCopy) {
        onCopy(text)
      }
      toast({
        title: "Copied!",
        description: "Message copied to clipboard",
      })
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Unable to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  const speakText = (text: string) => {
    if (isPlaying) {
      speechSynthesis.cancel()
      setIsPlaying(false)
      return
    }

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 0.9
    utterance.pitch = 1
    utterance.volume = 0.8

    utterance.onstart = () => setIsPlaying(true)
    utterance.onend = () => setIsPlaying(false)
    utterance.onerror = () => setIsPlaying(false)

    speechSynthesis.speak(utterance)
  }

  const handleEditSave = () => {
    if (onEdit && editContent.trim() !== message.content) {
      onEdit(message.id, editContent.trim())
    }
    setIsEditing(false)
  }

  const handleEditCancel = () => {
    setEditContent(message.content)
    setIsEditing(false)
  }

  const isUser = message.role === "user"

  return (
    <motion.div
      className={`flex gap-3 mb-6 ${isUser ? "justify-end" : "justify-start"}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {!isUser && (
        <div className="flex-shrink-0">
          <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full flex items-center justify-center">
            <Crown className="h-4 w-4 text-[#0A1D37]" />
          </div>
        </div>
      )}

      <div className={`flex flex-col max-w-[80%] ${isUser ? "items-end" : "items-start"}`}>
        {!isUser && message.model && <div className="text-xs text-yellow-400/70 mb-1 px-2">{message.model}</div>}

        <Card
          className={`p-4 ${
            isUser
              ? "bg-gradient-to-r from-yellow-400 to-yellow-500 text-[#0A1D37] border-yellow-400/30"
              : "bg-[#1A2F4A]/50 text-yellow-400 border-yellow-400/20"
          } backdrop-blur-sm`}
        >
          {message.isTyping ? (
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-yellow-400 rounded-full typing-dot"></div>
              <div className="w-2 h-2 bg-yellow-400 rounded-full typing-dot"></div>
              <div className="w-2 h-2 bg-yellow-400 rounded-full typing-dot"></div>
            </div>
          ) : isEditing ? (
            <div className="space-y-3">
              <textarea
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                className={`w-full min-h-[100px] p-3 rounded border resize-none ${
                  isUser
                    ? "bg-[#0A1D37]/20 text-[#0A1D37] border-[#0A1D37]/30"
                    : "bg-yellow-400/10 text-yellow-400 border-yellow-400/30"
                } focus:outline-none focus:ring-2 focus:ring-yellow-400/50`}
                placeholder="Edit your message..."
              />
              <div className="flex gap-2 justify-end">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={handleEditCancel}
                  className="h-7 px-3 text-red-400 hover:text-red-300 hover:bg-red-400/10"
                >
                  <X className="h-3 w-3 mr-1" />
                  Cancel
                </Button>
                <Button
                  size="sm"
                  onClick={handleEditSave}
                  className="h-7 px-3 bg-yellow-400 text-[#0A1D37] hover:bg-yellow-300"
                >
                  <Check className="h-3 w-3 mr-1" />
                  Save
                </Button>
              </div>
            </div>
          ) : (
            <div className="prose prose-sm max-w-none">
              <ReactMarkdown
                components={{
                  code({ node, inline, className, children, ...props }) {
                    const match = /language-(\w+)/.exec(className || "")
                    return !inline && match ? (
                      <SyntaxHighlighter
                        style={atomDark}
                        language={match[1]}
                        PreTag="div"
                        className="rounded-md !bg-[#0A1D37] !text-yellow-400"
                        {...props}
                      >
                        {String(children).replace(/\n$/, "")}
                      </SyntaxHighlighter>
                    ) : (
                      <code
                        className={`${
                          isUser ? "bg-[#0A1D37]/20 text-[#0A1D37]" : "bg-yellow-400/20 text-yellow-400"
                        } px-1 py-0.5 rounded text-sm`}
                        {...props}
                      >
                        {children}
                      </code>
                    )
                  },
                  p: ({ children }) => (
                    <p className={`mb-2 last:mb-0 ${isUser ? "text-[#0A1D37]" : "text-yellow-400"}`}>{children}</p>
                  ),
                  ul: ({ children }) => (
                    <ul className={`list-disc list-inside mb-2 ${isUser ? "text-[#0A1D37]" : "text-yellow-400"}`}>
                      {children}
                    </ul>
                  ),
                  ol: ({ children }) => (
                    <ol className={`list-decimal list-inside mb-2 ${isUser ? "text-[#0A1D37]" : "text-yellow-400"}`}>
                      {children}
                    </ol>
                  ),
                }}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          )}
        </Card>

        {!message.isTyping && !isEditing && (
          <div className="flex items-center gap-1 mt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => copyToClipboard(message.content)}
              className="h-6 px-2 text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
            >
              <Copy className="h-3 w-3" />
            </Button>
            {isUser && onEdit && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsEditing(true)}
                className="h-6 px-2 text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
              >
                <Edit className="h-3 w-3" />
              </Button>
            )}
            {isUser && onRegenerate && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onRegenerate}
                className="h-6 px-2 text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
              >
                <RotateCcw className="h-3 w-3" />
              </Button>
            )}
            {!isUser && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => speakText(message.content)}
                className="h-6 px-2 text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
              >
                {isPlaying ? <VolumeX className="h-3 w-3" /> : <Volume2 className="h-3 w-3" />}
              </Button>
            )}
            <span className="text-xs text-yellow-400/50 ml-2">{formatTimestamp(message.timestamp)}</span>
          </div>
        )}
      </div>

      {isUser && (
        <div className="flex-shrink-0">
          <div className="w-8 h-8 bg-gradient-to-r from-[#0A1D37] to-[#1A2F4A] rounded-full flex items-center justify-center border border-yellow-400/30">
            <User className="h-4 w-4 text-yellow-400" />
          </div>
        </div>
      )}
    </motion.div>
  )
}
