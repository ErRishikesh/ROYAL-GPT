// API Configuration for ROYAL GPT Multi-LLM Platform
export const API_CONFIG = {
  // Gemini Pro Configuration
  GEMINI: {
    API_KEY: "AIzaSyCdn0B0JJtgAPg_ywcGUvRkL-MjXURrj-4",
    BASE_URL: "https://generativelanguage.googleapis.com/v1beta",
    MODEL: "gemini-pro",
  },

  // OpenAI GPT-4 Configuration
  OPENAI: {
    API_KEY: "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",
    BASE_URL: "https://api.openai.com/v1",
    MODEL: "gpt-4",
  },

  // DeepSeek R1 Configuration
  DEEPSEEK: {
    API_KEY: "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",
    BASE_URL: "https://api.deepseek.com/v1",
    MODEL: "deepseek-reasoner",
  },

  // Qwen Coder Configuration
  QWEN: {
    API_KEY: "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",
    BASE_URL: "https://dashscope.aliyuncs.com/api/v1",
    MODEL: "qwen-coder-turbo",
  },

  GEMINI_PRO_FALLBACK: {
    API_KEY: "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",
  },

  // Rate limiting and retry configuration
  RATE_LIMIT: {
    MAX_REQUESTS_PER_MINUTE: 60,
    RETRY_ATTEMPTS: 3,
    RETRY_DELAY: 1000, // milliseconds
  },

  // Response configuration
  GENERATION: {
    MAX_TOKENS: 2048,
    TEMPERATURE: 0.7,
    TOP_P: 0.95,
    TOP_K: 40,
  },
}

// Utility function to check if API keys are configured
export const validateAPIKeys = () => {
  const configured = []
  const missing = []

  if (API_CONFIG.GEMINI.API_KEY && API_CONFIG.GEMINI.API_KEY !== "demo-key") {
    configured.push("Gemini Pro")
  } else {
    missing.push("Gemini Pro")
  }

  if (API_CONFIG.OPENAI.API_KEY && API_CONFIG.OPENAI.API_KEY !== "demo-key") {
    configured.push("OpenAI GPT-4")
  } else {
    missing.push("OpenAI GPT-4")
  }

  if (API_CONFIG.DEEPSEEK.API_KEY && API_CONFIG.DEEPSEEK.API_KEY !== "demo-key") {
    configured.push("DeepSeek R1")
  } else {
    missing.push("DeepSeek R1")
  }

  if (API_CONFIG.QWEN.API_KEY && API_CONFIG.QWEN.API_KEY !== "demo-key") {
    configured.push("Qwen Coder")
  } else {
    missing.push("Qwen Coder")
  }

  return {
    isValid: missing.length === 0,
    configured,
    missing,
  }
}
