// LLM API service integrations for ROYAL GPT

interface LLMResponse {
  model: string
  content: string
  timestamp: Date
  isTyping?: boolean
  isBest?: boolean
}

interface StreamCallback {
  onChunk: (chunk: string, model: string) => void
  onComplete: (model: string) => void
  onError: (error: string, model: string) => void
}

import { API_CONFIG } from "./api-config"

// Gemini Pro API Service via OpenRouter
export class GeminiService {
  private apiKey: string

  constructor() {
    this.apiKey = API_CONFIG.GEMINI_PRO_FALLBACK.API_KEY
  }

  async generateResponse(prompt: string, callback: StreamCallback): Promise<void> {
    try {
      console.log("[v0] Starting Gemini API call")
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://royal-gpt.vercel.app",
          "X-Title": "ROYAL GPT",
        },
        body: JSON.stringify({
          model: "google/gemini-pro",
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7,
          max_tokens: 2048,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.error("[v0] Gemini API error:", errorText)
        throw new Error(`Gemini API error: ${response.status} - ${errorText}`)
      }

      const data = await response.json()
      console.log("[v0] Gemini response received:", data)
      const content = data.choices?.[0]?.message?.content || "No response generated"

      // Simulate streaming by chunking the response
      const words = content.split(" ")
      for (let i = 0; i < words.length; i += 3) {
        const chunk = words.slice(i, i + 3).join(" ") + " "
        callback.onChunk(chunk, "Gemini Pro")
        await new Promise((resolve) => setTimeout(resolve, 50))
      }

      callback.onComplete("Gemini Pro")
    } catch (error) {
      console.error("[v0] Gemini error:", error)
      callback.onError(error instanceof Error ? error.message : "Unknown error", "Gemini Pro")
    }
  }
}

// OpenAI GPT-4 API Service via OpenRouter
export class OpenAIService {
  private apiKey: string

  constructor() {
    this.apiKey = API_CONFIG.OPENAI.API_KEY
  }

  async generateResponse(prompt: string, callback: StreamCallback): Promise<void> {
    try {
      console.log("[v0] Starting OpenAI API call")
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://royal-gpt.vercel.app",
          "X-Title": "ROYAL GPT",
        },
        body: JSON.stringify({
          model: "openai/gpt-4o", // Updated to GPT-4o model via OpenRouter
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7,
          max_tokens: 2048,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.error("[v0] OpenAI API error:", errorText)
        throw new Error(`OpenAI API error: ${response.status} - ${errorText}`)
      }

      const data = await response.json()
      console.log("[v0] OpenAI response received")
      const content = data.choices?.[0]?.message?.content || "No response generated"

      // Simulate streaming
      const words = content.split(" ")
      for (let i = 0; i < words.length; i += 3) {
        const chunk = words.slice(i, i + 3).join(" ") + " "
        callback.onChunk(chunk, "GPT-4")
        await new Promise((resolve) => setTimeout(resolve, 60))
      }

      callback.onComplete("GPT-4")
    } catch (error) {
      console.error("[v0] OpenAI error:", error)
      callback.onError(error instanceof Error ? error.message : "Unknown error", "GPT-4")
    }
  }
}

// DeepSeek R1 API Service via OpenRouter
export class DeepSeekService {
  private apiKey: string

  constructor() {
    this.apiKey = API_CONFIG.DEEPSEEK.API_KEY
  }

  async generateResponse(prompt: string, callback: StreamCallback): Promise<void> {
    try {
      console.log("[v0] Starting DeepSeek API call")
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://royal-gpt.vercel.app",
          "X-Title": "ROYAL GPT",
        },
        body: JSON.stringify({
          model: "deepseek/deepseek-r1", // Updated to correct DeepSeek R1 model via OpenRouter
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7,
          max_tokens: 2048,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.error("[v0] DeepSeek API error:", errorText)
        throw new Error(`DeepSeek API error: ${response.status} - ${errorText}`)
      }

      const data = await response.json()
      console.log("[v0] DeepSeek response received")
      const content = data.choices?.[0]?.message?.content || "No response generated"

      // Simulate streaming
      const words = content.split(" ")
      for (let i = 0; i < words.length; i += 3) {
        const chunk = words.slice(i, i + 3).join(" ") + " "
        callback.onChunk(chunk, "DeepSeek R1")
        await new Promise((resolve) => setTimeout(resolve, 70))
      }

      callback.onComplete("DeepSeek R1")
    } catch (error) {
      console.error("[v0] DeepSeek error:", error)
      callback.onError(error instanceof Error ? error.message : "Unknown error", "DeepSeek R1")
    }
  }
}

// Qwen Coder API Service via OpenRouter
export class QwenService {
  private apiKey: string

  constructor() {
    this.apiKey = API_CONFIG.QWEN.API_KEY
  }

  async generateResponse(prompt: string, callback: StreamCallback): Promise<void> {
    try {
      console.log("[v0] Starting Qwen API call")
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://royal-gpt.vercel.app",
          "X-Title": "ROYAL GPT",
        },
        body: JSON.stringify({
          model: "qwen/qwen-2.5-coder-32b-instruct", // Updated to correct Qwen Coder model via OpenRouter
          messages: [{ role: "user", content: `As an expert coder, ${prompt}` }],
          temperature: 0.7,
          max_tokens: 2048,
        }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.error("[v0] Qwen API error:", errorText)
        throw new Error(`Qwen API error: ${response.status} - ${errorText}`)
      }

      const data = await response.json()
      console.log("[v0] Qwen response received")
      const content = data.choices?.[0]?.message?.content || "No response generated"

      // Simulate streaming
      const words = content.split(" ")
      for (let i = 0; i < words.length; i += 3) {
        const chunk = words.slice(i, i + 3).join(" ") + " "
        callback.onChunk(chunk, "Qwen Coder")
        await new Promise((resolve) => setTimeout(resolve, 80))
      }

      callback.onComplete("Qwen Coder")
    } catch (error) {
      console.error("[v0] Qwen error:", error)
      callback.onError(error instanceof Error ? error.message : "Unknown error", "Qwen Coder")
    }
  }
}

// Unified Multi-LLM Service
export class MultiLLMService {
  private gemini: GeminiService
  private openai: OpenAIService
  private deepseek: DeepSeekService
  private qwen: QwenService

  constructor() {
    this.gemini = new GeminiService()
    this.openai = new OpenAIService()
    this.deepseek = new DeepSeekService()
    this.qwen = new QwenService()
  }

  async generateSingleResponse(
    prompt: string,
    model: string,
    onUpdate: (response: LLMResponse) => void,
    onComplete: () => void,
    abortSignal?: AbortSignal,
  ): Promise<void> {
    const response: LLMResponse = {
      model,
      content: "",
      timestamp: new Date(),
      isTyping: true,
    }

    onUpdate(response)

    const callback: StreamCallback = {
      onChunk: (chunk: string) => {
        if (abortSignal?.aborted) return
        response.content += chunk
        onUpdate(response)
      },
      onComplete: () => {
        if (abortSignal?.aborted) return
        response.isTyping = false
        onUpdate(response)
        onComplete()
      },
      onError: (error: string) => {
        if (abortSignal?.aborted) return
        response.content = `Error: ${error}`
        response.isTyping = false
        onUpdate(response)
        onComplete()
      },
    }

    try {
      if (abortSignal?.aborted) return

      switch (model) {
        case "Gemini":
          await this.gemini.generateResponse(prompt, callback)
          break
        case "GPT-4":
          await this.openai.generateResponse(prompt, callback)
          break
        case "DeepSeek":
          await this.deepseek.generateResponse(prompt, callback)
          break
        case "Qwen":
          await this.qwen.generateResponse(prompt, callback)
          break
        default:
          callback.onError("Unknown model selected", model)
      }
    } catch (error) {
      if (!abortSignal?.aborted) {
        callback.onError(error instanceof Error ? error.message : "Unknown error", model)
      }
    }
  }

  async generateMultipleResponses(
    prompt: string,
    onUpdate: (responses: LLMResponse[]) => void,
    onComplete: () => void,
    abortSignal?: AbortSignal,
  ): Promise<void> {
    const responses: Map<string, LLMResponse> = new Map()
    const models = ["Gemini Pro", "GPT-4", "DeepSeek R1", "Qwen Coder"]
    let completedCount = 0

    // Initialize responses
    models.forEach((model) => {
      responses.set(model, {
        model,
        content: "",
        timestamp: new Date(),
        isTyping: true,
      })
    })

    onUpdate(Array.from(responses.values()))

    const callback: StreamCallback = {
      onChunk: (chunk: string, model: string) => {
        if (abortSignal?.aborted) return
        const response = responses.get(model)
        if (response) {
          response.content += chunk
          onUpdate(Array.from(responses.values()))
        }
      },
      onComplete: (model: string) => {
        if (abortSignal?.aborted) return
        const response = responses.get(model)
        if (response) {
          response.isTyping = false
          response.isBest = completedCount === 0 // Mark first completed as best
          completedCount++
          onUpdate(Array.from(responses.values()))

          if (completedCount === models.length) {
            onComplete()
          }
        }
      },
      onError: (error: string, model: string) => {
        if (abortSignal?.aborted) return
        const response = responses.get(model)
        if (response) {
          response.content = `Error: ${error}`
          response.isTyping = false
          completedCount++
          onUpdate(Array.from(responses.values()))

          if (completedCount === models.length) {
            onComplete()
          }
        }
      },
    }

    // Check for abort before starting
    if (abortSignal?.aborted) return

    // Start all API calls concurrently
    Promise.all([
      this.gemini.generateResponse(prompt, callback),
      this.openai.generateResponse(prompt, callback),
      this.deepseek.generateResponse(prompt, callback),
      this.qwen.generateResponse(prompt, callback),
    ]).catch((error) => {
      if (!abortSignal?.aborted) {
        console.error("Multi-LLM generation error:", error)
      }
    })
  }
}

// Export singleton instance
export const multiLLMService = new MultiLLMService()
