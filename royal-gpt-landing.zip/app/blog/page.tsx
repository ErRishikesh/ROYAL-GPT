import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, Clock, User, ArrowRight, TrendingUp, Lightbulb } from "lucide-react"
import Link from "next/link"

export default function Blog() {
  const blogPosts = [
    {
      id: 1,
      title: "The Future of Multi-LLM Platforms: Why One Size Doesn't Fit All",
      excerpt:
        "Discover why using multiple AI models is more effective than relying on a single LLM for all your tasks.",
      author: "ROYAL GPT Team",
      date: "January 15, 2025",
      readTime: "5 min read",
      category: "AI Insights",
      featured: true,
    },
    {
      id: 2,
      title: "Maximizing Productivity with Specialized AI Models",
      excerpt: "Learn how to choose the right AI model for specific tasks and boost your productivity by 300%.",
      author: "ROYAL GPT Team",
      date: "January 10, 2025",
      readTime: "7 min read",
      category: "Productivity",
      featured: false,
    },
    {
      id: 3,
      title: "From Research to Code: A Complete Workflow with ROYAL GPT",
      excerpt:
        "Step-by-step guide on using different AI models for a complete project workflow from research to implementation.",
      author: "ROYAL GPT Team",
      date: "January 5, 2025",
      readTime: "10 min read",
      category: "Tutorial",
      featured: false,
    },
    {
      id: 4,
      title: "Breaking Down AI Model Costs: The Economics of LLM Usage",
      excerpt: "Comprehensive analysis of AI model pricing and how ROYAL GPT saves users thousands of rupees annually.",
      author: "ROYAL GPT Team",
      date: "December 28, 2024",
      readTime: "6 min read",
      category: "Economics",
      featured: false,
    },
    {
      id: 5,
      title: "Best Practices for Academic Research with AI",
      excerpt: "How students and researchers can leverage Gemini Pro and other models for academic excellence.",
      author: "ROYAL GPT Team",
      date: "December 20, 2024",
      readTime: "8 min read",
      category: "Education",
      featured: false,
    },
    {
      id: 6,
      title: "Code Quality Revolution: How Qwen Coder Changes Development",
      excerpt: "Exploring how specialized coding AI models are transforming software development practices.",
      author: "ROYAL GPT Team",
      date: "December 15, 2024",
      readTime: "9 min read",
      category: "Development",
      featured: false,
    },
  ]

  const categories = ["All", "AI Insights", "Productivity", "Tutorial", "Economics", "Education", "Development"]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <ArrowLeft className="w-5 h-5 text-muted-foreground hover:text-foreground transition-colors" />
              <span className="text-muted-foreground hover:text-foreground transition-colors">Back to Home</span>
            </Link>
          </div>
          <div className="flex items-center space-x-2">
            <img src="/images/royal-gpt-logo.png" alt="ROYAL GPT logo" className="w-8 h-8 rounded-lg" />
            <span className="text-xl font-bold text-foreground">ROYAL GPT</span>
          </div>
          <Button asChild>
            <a href="https://royal-gpt.base44.app/login?from_url=https://royal-gpt.base44.app">Get Started</a>
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="container mx-auto px-4 text-center">
          <Badge variant="secondary" className="mb-6">
            <TrendingUp className="w-4 h-4 mr-2" />
            Blog
          </Badge>
          <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6 text-balance">
            ROYAL GPT
            <span className="text-primary block">Blog</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto text-pretty">
            Insights, tutorials, and best practices for maximizing your productivity with multi-LLM AI platforms.
          </p>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((category) => (
              <Badge
                key={category}
                variant={category === "All" ? "default" : "secondary"}
                className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                {category}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Post */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Featured Article</h2>
          </div>
          {blogPosts
            .filter((post) => post.featured)
            .map((post) => (
              <Card key={post.id} className="border-border max-w-4xl mx-auto">
                <CardHeader>
                  <div className="flex items-center gap-2 mb-4">
                    <Badge variant="secondary">{post.category}</Badge>
                    <Badge variant="outline">Featured</Badge>
                  </div>
                  <CardTitle className="text-3xl lg:text-4xl text-balance">{post.title}</CardTitle>
                  <CardDescription className="text-lg mt-4">{post.excerpt}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-6 text-sm text-muted-foreground mb-6">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      <span>{post.author}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                  <Button size="lg">
                    Read Full Article
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
        </div>
      </section>

      {/* Recent Posts */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Recent Articles</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Stay updated with the latest insights and tutorials
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts
              .filter((post) => !post.featured)
              .map((post) => (
                <Card key={post.id} className="border-border hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <Badge variant="secondary" className="w-fit mb-2">
                      {post.category}
                    </Badge>
                    <CardTitle className="text-xl text-balance">{post.title}</CardTitle>
                    <CardDescription className="text-base">{post.excerpt}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        <span>{post.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                    <Button variant="outline" className="w-full bg-transparent">
                      Read More
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card className="border-border max-w-2xl mx-auto text-center">
            <CardHeader>
              <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Lightbulb className="w-8 h-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Stay Updated</CardTitle>
              <CardDescription className="text-lg">
                Get the latest insights and tutorials delivered to your inbox
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <Button>Subscribe</Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">No spam, unsubscribe at any time</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30">
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <img src="/images/royal-gpt-logo.png" alt="ROYAL GPT logo" className="w-8 h-8 rounded-lg" />
              <span className="text-xl font-bold text-foreground">ROYAL GPT</span>
            </div>
            <p className="text-muted-foreground mb-4">Empowering productivity through multi-LLM AI platforms</p>
            <div className="flex justify-center space-x-4">
              <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                Home
              </Link>
              <Link href="/documentation" className="text-muted-foreground hover:text-foreground transition-colors">
                Documentation
              </Link>
              <a
                href="https://royal-gpt.base44.app/login?from_url=https://royal-gpt.base44.app"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Platform
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
