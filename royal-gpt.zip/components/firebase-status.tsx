"use client"

import { isFirebaseConfigured } from "@/lib/firebase"
import { AlertTriangle, CheckCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function FirebaseStatus() {
  const configured = isFirebaseConfigured()

  if (configured) {
    return (
      <Alert className="border-green-200 bg-green-50 text-green-800">
        <CheckCircle className="h-4 w-4" />
        <AlertDescription>Firebase is properly configured and ready to use.</AlertDescription>
      </Alert>
    )
  }

  return (
    <Alert className="border-amber-200 bg-amber-50 text-amber-800">
      <AlertTriangle className="h-4 w-4" />
      <AlertDescription>
        Firebase is not configured. Add your Firebase environment variables to enable authentication and data storage.
        <br />
        <span className="text-sm mt-2 block">Currently running in demo mode with limited functionality.</span>
      </AlertDescription>
    </Alert>
  )
}
