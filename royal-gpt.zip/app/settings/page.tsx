"use client"

import { ProtectedRoute } from "@/components/auth/protected-route"
import { motion } from "framer-motion"
import { useRouter } from "next/navigation"
import { ArrowLeft, Trash2 } from "lucide-react"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export default function SettingsPage() {
  const router = useRouter()

  const handleDeleteAccount = () => {
    // Implementation for deleting account
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-[#0A1D37] via-[#1A2F4A] to-[#0A1D37]">
        <div className="container mx-auto px-4 py-8">
          <motion.div className="max-w-4xl mx-auto" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="flex items-center gap-3 mb-8">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => router.back()}
                className="text-yellow-400 hover:text-yellow-300"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <Trash2 className="h-8 w-8 text-yellow-400" />
              <h1 className="text-3xl font-serif text-yellow-400">Settings</h1>
            </div>

            <div className="max-h-[calc(100vh-200px)] overflow-y-auto space-y-6 pr-2">
              <Card className="bg-red-900/20 border-red-400/30">
                <CardHeader>
                  <CardTitle className="text-red-400 flex items-center gap-2">
                    <Trash2 className="h-5 w-5" />
                    Danger Zone
                  </CardTitle>
                  <CardDescription className="text-red-400/70">Permanent actions that cannot be undone</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-red-400 font-medium">Delete Account</p>
                      <p className="text-red-400/70 text-sm">Permanently delete your account and all associated data</p>
                    </div>
                    <Button variant="destructive" onClick={handleDeleteAccount} className="bg-red-600 hover:bg-red-700">
                      Delete Account
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </div>
      </div>
    </ProtectedRoute>
  )
}
