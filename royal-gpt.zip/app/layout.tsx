import type React from "react"
import type { Metadata } from "next"
import { Inter, Playfair_Display } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { AuthProvider } from "@/contexts/auth-context"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

const playfair = Playfair_Display({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-playfair",
})

export const metadata: Metadata = {
  title: "ROYAL GPT - Multi-LLM AI Assistant",
  description: "Experience the luxury of AI with ROYAL GPT - Your premium multi-LLM chatbot platform",
  generator: "ROYAL GPT",
  keywords: ["AI", "ChatGPT", "Gemini", "DeepSeek", "Qwen", "Multi-LLM", "Chatbot"],
  authors: [{ name: "ROYAL GPT Team" }],
  viewport: "width=device-width, initial-scale=1",
  themeColor: "#0A1D37",
  manifest: "/manifest.json",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <head>
        <style>{`
          html {
            font-family: ${inter.style.fontFamily};
            --font-sans: ${inter.variable};
            --font-serif: ${playfair.variable};
          }
        `}</style>
      </head>
      <body className="font-sans antialiased">
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <AuthProvider>
            {children}
            <Toaster />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
