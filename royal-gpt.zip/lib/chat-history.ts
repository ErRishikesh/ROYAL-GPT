import { db, isFirebaseConfigured } from "@/lib/firebase"
import { collection, addDoc, getDocs, doc, updateDoc, deleteDoc, query, where, onSnapshot } from "firebase/firestore"

export interface ChatSession {
  id: string
  title: string
  userId: string
  messages: Message[]
  llmResponses: LLMResponse[]
  createdAt: Date
  updatedAt: Date
  isPinned?: boolean
}

export interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  model?: string
  timestamp: Date
  isTyping?: boolean
}

export interface LLMResponse {
  model: string
  content: string
  timestamp: Date
  isTyping?: boolean
  isBest?: boolean
}

class ChatHistoryService {
  private isConfigured = isFirebaseConfigured()

  async saveChatSession(
    userId: string,
    title: string,
    messages: Message[],
    llmResponses: LLMResponse[],
  ): Promise<string | null> {
    if (!this.isConfigured) {
      console.log("[v0] Firebase not configured, skipping chat save")
      return null
    }

    try {
      const chatSession: Omit<ChatSession, "id"> = {
        title,
        userId,
        messages,
        llmResponses,
        createdAt: new Date(),
        updatedAt: new Date(),
        isPinned: false,
      }

      const docRef = await addDoc(collection(db, "chatSessions"), chatSession)
      return docRef.id
    } catch (error) {
      console.error("Error saving chat session:", error)
      return null
    }
  }

  async updateChatSession(sessionId: string, messages: Message[], llmResponses: LLMResponse[]): Promise<boolean> {
    if (!this.isConfigured) return false

    try {
      const sessionRef = doc(db, "chatSessions", sessionId)
      await updateDoc(sessionRef, {
        messages,
        llmResponses,
        updatedAt: new Date(),
      })
      return true
    } catch (error) {
      console.error("Error updating chat session:", error)
      return false
    }
  }

  async getChatSessions(userId: string): Promise<ChatSession[]> {
    if (!this.isConfigured) return []

    try {
      const q = query(collection(db, "chatSessions"), where("userId", "==", userId))

      const querySnapshot = await getDocs(q)
      const sessions = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        updatedAt: doc.data().updatedAt?.toDate() || new Date(),
      })) as ChatSession[]

      return sessions.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())
    } catch (error) {
      console.error("Error fetching chat sessions:", error)
      return []
    }
  }

  async deleteChatSession(sessionId: string): Promise<boolean> {
    if (!this.isConfigured) return false

    try {
      await deleteDoc(doc(db, "chatSessions", sessionId))
      return true
    } catch (error) {
      console.error("Error deleting chat session:", error)
      return false
    }
  }

  async renameChatSession(sessionId: string, newTitle: string): Promise<boolean> {
    if (!this.isConfigured) return false

    try {
      const sessionRef = doc(db, "chatSessions", sessionId)
      await updateDoc(sessionRef, {
        title: newTitle,
        updatedAt: new Date(),
      })
      return true
    } catch (error) {
      console.error("Error renaming chat session:", error)
      return false
    }
  }

  async togglePinChatSession(sessionId: string, isPinned: boolean): Promise<boolean> {
    if (!this.isConfigured) return false

    try {
      const sessionRef = doc(db, "chatSessions", sessionId)
      await updateDoc(sessionRef, {
        isPinned,
        updatedAt: new Date(),
      })
      return true
    } catch (error) {
      console.error("Error toggling pin status:", error)
      return false
    }
  }

  subscribeToUserChats(userId: string, callback: (chats: ChatSession[]) => void) {
    if (!this.isConfigured) {
      callback([])
      return () => {}
    }

    const q = query(collection(db, "chatSessions"), where("userId", "==", userId))

    return onSnapshot(q, (querySnapshot) => {
      const chats = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        updatedAt: doc.data().updatedAt?.toDate() || new Date(),
      })) as ChatSession[]

      const sortedChats = chats.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())
      callback(sortedChats)
    })
  }
}

export const chatHistoryService = new ChatHistoryService()
