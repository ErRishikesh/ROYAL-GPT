import { Button } from "your-button-library"
import { FileText, Share, Download, Copy } from "your-icon-library"

export function EnhancedChatFeatures() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Button variant="outline" className="text-yellow-400 border-yellow-400/30 bg-transparent">
          <FileText className="h-4 w-4 mr-2" />
          Export Chat
        </Button>
        <Button variant="outline" className="text-yellow-400 border-yellow-400/30 bg-transparent">
          <Share className="h-4 w-4 mr-2" />
          Share Chat
        </Button>
        <Button variant="outline" className="text-yellow-400 border-yellow-400/30 bg-transparent">
          <Download className="h-4 w-4 mr-2" />
          Download PDF
        </Button>
        <Button variant="outline" className="text-yellow-400 border-yellow-400/30 bg-transparent">
          <Copy className="h-4 w-4 mr-2" />
          Copy All
        </Button>
      </div>
    </div>
  )
}
