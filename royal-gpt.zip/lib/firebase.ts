import { initializeApp } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"

const firebaseConfig = {
  apiKey: "AIzaSyBuzX10vt83jZseOmxbJ0-BlUZUFxoQOTU",
  authDomain: "royal-gpt-c6cca.firebaseapp.com",
  projectId: "royal-gpt-c6cca",
  storageBucket: "royal-gpt-c6cca.firebasestorage.app",
  messagingSenderId: "580884689626",
  appId: "1:580884689626:web:dfa9a23c09184dc6e52be3",
}

export const isFirebaseConfigured = () => {
  return true // Always true now with real config
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize Firebase services
export const auth = getAuth(app)
export const db = getFirestore(app)
export const storage = getStorage(app)

export default app
