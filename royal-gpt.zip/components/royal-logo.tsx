"use client"

import { motion } from "framer-motion"

export function RoyalLogo({ size = 40 }: { size?: number }) {
  return (
    <motion.div
      className="flex items-center gap-2"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        className="crown-glow"
        animate={{ rotate: [0, 5, -5, 0] }}
        transition={{ duration: 4, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
      >
        {/* Crown */}
        <path
          d="M20 60 L30 40 L40 50 L50 30 L60 50 L70 40 L80 60 L75 70 L25 70 Z"
          fill="#FFD700"
          stroke="#FFF4B3"
          strokeWidth="1"
        />
        {/* Crown jewels */}
        <circle cx="35" cy="55" r="2" fill="#FF6B6B" />
        <circle cx="50" cy="50" r="3" fill="#4ECDC4" />
        <circle cx="65" cy="55" r="2" fill="#45B7D1" />

        {/* AI Brain */}
        <motion.g animate={{ opacity: [0.7, 1, 0.7] }} transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}>
          <path d="M35 75 Q50 65 65 75 Q65 85 50 90 Q35 85 35 75" fill="none" stroke="#FFD700" strokeWidth="2" />
          <path d="M40 78 Q50 73 60 78" fill="none" stroke="#FFD700" strokeWidth="1" />
          <path d="M42 82 Q50 79 58 82" fill="none" stroke="#FFD700" strokeWidth="1" />
        </motion.g>

        {/* Neural connections */}
        <motion.g
          animate={{ opacity: [0.3, 0.8, 0.3] }}
          transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, staggerChildren: 0.2 }}
        >
          <circle cx="45" cy="77" r="1" fill="#FFD700" />
          <circle cx="55" cy="77" r="1" fill="#FFD700" />
          <circle cx="50" cy="83" r="1" fill="#FFD700" />
        </motion.g>
      </motion.svg>

      <motion.div
        className="flex flex-col"
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <h1 className="font-serif text-xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-200 bg-clip-text text-transparent">
          ROYAL GPT
        </h1>
        <p className="text-xs text-yellow-400/80 -mt-1">Multi-LLM Assistant</p>
      </motion.div>
    </motion.div>
  )
}
