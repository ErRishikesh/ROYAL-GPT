"use client"

import React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChatMessage } from "./chat-message"
import { Crown, Star, Zap, Code, Brain } from "lucide-react"

interface LLMResponse {
  model: string
  content: string
  timestamp: Date
  isTyping?: boolean
  isBest?: boolean
}

interface LLMTabsProps {
  responses: LLMResponse[]
  onSelectBest: (model: string) => void
}

const modelIcons = {
  "Gemini Pro": Brain,
  "GPT-4": Crown,
  "DeepSeek R1": Zap,
  "Qwen Coder": Code,
}

const modelColors = {
  "Gemini Pro": "from-blue-400 to-blue-500",
  "GPT-4": "from-green-400 to-green-500",
  "DeepSeek R1": "from-purple-400 to-purple-500",
  "Qwen Coder": "from-orange-400 to-orange-500",
}

export function LLMTabs({ responses, onSelectBest }: LLMTabsProps) {
  const [selectedTab, setSelectedTab] = useState(responses[0]?.model || "")

  if (responses.length === 0) return null

  return (
    <Card className="bg-[#0A1D37]/50 backdrop-blur-lg border-yellow-400/20 p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-yellow-400">Multi-LLM Responses</h3>
        <Badge variant="outline" className="border-yellow-400/30 text-yellow-400">
          {responses.length} models
        </Badge>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-yellow-400/5 border border-yellow-400/20">
          {responses.map((response) => {
            const Icon = modelIcons[response.model as keyof typeof modelIcons] || Crown
            const colorClass =
              modelColors[response.model as keyof typeof modelColors] || "from-yellow-400 to-yellow-500"

            return (
              <TabsTrigger
                key={response.model}
                value={response.model}
                className="relative data-[state=active]:bg-yellow-400/10 data-[state=active]:text-yellow-400 text-yellow-400/70 flex items-center gap-2"
              >
                <div className={`w-4 h-4 rounded-full bg-gradient-to-r ${colorClass} flex items-center justify-center`}>
                  <Icon className="h-2.5 w-2.5 text-white" />
                </div>
                <span className="hidden sm:inline">{response.model}</span>
                {response.isBest && (
                  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute -top-1 -right-1">
                    <Star className="h-3 w-3 text-yellow-400 fill-yellow-400" />
                  </motion.div>
                )}
              </TabsTrigger>
            )
          })}
        </TabsList>

        {responses.map((response) => (
          <TabsContent key={response.model} value={response.model} className="mt-4">
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-6 h-6 rounded-full bg-gradient-to-r ${
                      modelColors[response.model as keyof typeof modelColors]
                    } flex items-center justify-center`}
                  >
                    {React.createElement(modelIcons[response.model as keyof typeof modelIcons] || Crown, {
                      className: "h-3 w-3 text-white",
                    })}
                  </div>
                  <h4 className="font-medium text-yellow-400">{response.model}</h4>
                  {response.isBest && (
                    <Badge className="bg-yellow-400/20 text-yellow-400 border-yellow-400/30">Best</Badge>
                  )}
                </div>
                {!response.isBest && !response.isTyping && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onSelectBest(response.model)}
                    className="text-yellow-400/70 hover:text-yellow-400 hover:bg-yellow-400/10"
                  >
                    <Star className="h-4 w-4 mr-1" />
                    Mark as Best
                  </Button>
                )}
              </div>

              <ChatMessage
                message={{
                  id: `${response.model}-${response.timestamp.getTime()}`,
                  content: response.content,
                  role: "assistant",
                  model: response.model,
                  timestamp: response.timestamp,
                  isTyping: response.isTyping,
                }}
              />
            </motion.div>
          </TabsContent>
        ))}
      </Tabs>
    </Card>
  )
}
